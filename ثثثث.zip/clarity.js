/* clarity-js v0.8.69: https://github.com/microsoft/clarity (License: MIT) */ ! function() {
    "use strict";
    var t, e, n, a, i, r, o, u, c, l, s, d, f, h, p, g, v, m, y, b, w, k, S, E, T, N, M, _, O, x, I, D, C, A, P, R, L, Y, j, X, W, H, q, U, z, F, V, B, J, K, G, Z, Q, $, tt, et, nt, at, it, rt, ot, ut, ct, lt, st, dt, ft, ht, pt, gt, vt, mt, yt, bt, wt, kt, St, Et, Tt, Nt, Mt, _t, Ot, xt, It, Dt, Ct, At, Pt, Rt, Lt, Yt, jt, Xt, Wt, Ht, qt, Ut, zt, Ft, Vt, Bt, Jt, Kt, Gt, Zt, Qt, $t, te, ee, ne, ae, ie, re, oe, ue, ce, le, se, de, fe, he, pe, ge, ve, me, ye, be, we, ke, Se, Ee, Te, Ne, Me, _e, Oe, xe, Ie, De, Ce, Ae, Pe, Re, Le, Ye, je, Xe, We, He, qe, Ue, ze, Fe, Ve, Be, Je, Ke, Ge, Ze, Qe, $e, tn, en, nn, an, rn, on, un, cn, ln, sn, dn, fn, hn, pn, gn, vn, mn, yn, bn, wn, kn, Sn, En, Tn, Nn, Mn, _n, On, xn = {
        projectId: null,
        delay: 1e3,
        lean: !1,
        lite: !1,
        track: !0,
        content: !0,
        drop: [],
        mask: [],
        unmask: [],
        regions: [],
        cookies: [],
        fraud: !0,
        checksum: [],
        report: null,
        upload: null,
        fallback: null,
        upgrade: null,
        action: null,
        dob: null,
        delayDom: !1,
        throttleDom: !0,
        conversions: !1,
        includeSubdomains: !0,
        modules: [],
        diagnostics: !1,
        restart: 250
    };

    function In(t) {
        return window.Zone && "__symbol__" in window.Zone ? window.Zone.__symbol__(t) : t
    }

    function Dn() {
        return performance.now() + performance.timeOrigin
    }

    function Cn(e) {
        var n, a, i;
        return void 0 === e && (e = null), n = 0 === t ? Dn() : t, a = e && e.timeStamp > 0 ? e.timeStamp : performance.now(), i = e && e.view ? e.view.performance.timeOrigin : performance.timeOrigin, Math.max(Math.round(a + i - n), 0)
    }

    function An(t, e) {
        var n, a, i, r;
        for (void 0 === e && (e = null), i = a = 5381, r = 0; r < t.length; r += 2) a = (a << 5) + a ^ t.charCodeAt(r), r + 1 < t.length && (i = (i << 5) + i ^ t.charCodeAt(r + 1));
        return n = Math.abs(a + 11579 * i), (e ? n % Math.pow(2, e) : n).toString(36)
    }

    function Pn(t, e, n, a, r) {
        if (void 0 === a && (a = !1), t) {
            if ("input" == e && ("checkbox" === r || "radio" === r)) return t;
            switch (n) {
                case 0:
                    return t;
                case 1:
                    switch (e) {
                        case "*T":
                        case "value":
                        case "placeholder":
                        case "click":
                            return function(t) {
                                var e, n, a, r = -1,
                                    o = 0,
                                    c = !1,
                                    l = !1,
                                    s = !1,
                                    d = null;
                                for (Wn(), e = 0; e < t.length; e++) n = t.charCodeAt(e), c = c || n >= 48 && n <= 57, l = l || 64 === n, s = 9 === n || 10 === n || 13 === n || 32 === n, (0 === e || e === t.length - 1 || s) && ((c || l) && (null === d && (d = t.split("")), a = t.substring(r + 1, s ? e : e + 1), a = i && null !== u ? a.match(u) ? a : jn(a, "▪", "▫") : Yn(a), d.splice(r + 1 - o, a.length, a), o += a.length - 1), s && (c = !1, l = !1, r = e));
                                return d ? d.join("") : t
                            }(t);
                        case "input":
                        case "change":
                            return Xn(t)
                    }
                    return t;
                case 2:
                case 3:
                    switch (e) {
                        case "*T":
                        case "data-":
                            return a ? Ln(t) : Yn(t);
                        case "src":
                        case "srcset":
                        case "title":
                        case "alt":
                        case "href":
                        case "xlink:href":
                            return 3 === n ? (null == t ? void 0 : t.startsWith("blob:")) ? "blob:" : "" : t;
                        case "value":
                        case "click":
                        case "input":
                        case "change":
                            return Xn(t);
                        case "placeholder":
                            return Yn(t)
                    }
                    break;
                case 4:
                    switch (e) {
                        case "*T":
                        case "data-":
                            return a ? Ln(t) : Yn(t);
                        case "value":
                        case "input":
                        case "click":
                        case "change":
                            return Array(5).join("•");
                        case "checksum":
                            return ""
                    }
                    break;
                case 5:
                    switch (e) {
                        case "*T":
                        case "data-":
                            return jn(t, "▪", "▫");
                        case "value":
                        case "input":
                        case "click":
                        case "change":
                            return Array(5).join("•");
                        case "checksum":
                        case "src":
                        case "srcset":
                        case "alt":
                        case "title":
                            return ""
                    }
            }
        }
        return t
    }

    function Rn(t, e, n) {
        var i, r, o;
        return void 0 === e && (e = !1), void 0 === n && (n = !1), i = t, e ? i = "https://Electron" : (r = xn.drop) && r.length > 0 && t && t.indexOf("?") > 0 && (i = (o = t.split("?"))[0] + "?" + o[1].split("&").map((function(t) {
            return r.some((function(e) {
                return 0 === t.indexOf(e + "=")
            })) ? t.split("=")[0] + "=*na*" : t
        })).join("&")), n && (i = i.substring(0, a)), i
    }

    function Ln(t) {
        var e, n, a, i, r = t.trim();
        return r.length > 0 ? (e = r[0], n = t.indexOf(e), a = t.substr(0, n), i = t.substr(n + r.length), a + r.length.toString(36) + i) : t
    }

    function Yn(t) {
        return t.replace(n, "•")
    }

    function jn(t, e, n) {
        return Wn(), t ? t.replace(o, e).replace(r, n) : t
    }

    function Xn(t) {
        var e, n = 5 * (Math.floor(t.length / 5) + 1),
            a = "";
        for (e = 0; e < n; e++) a += e > 0 && e % 5 == 0 ? " " : "•";
        return a
    }

    function Wn() {
        if (i && null === r) try {
            r = new RegExp("\\p{N}", "gu"), o = new RegExp("\\p{L}", "gu"), u = new RegExp("\\p{Sc}", "gu")
        } catch (t) {
            i = !1
        }
    }

    function Hn() {
        s && (c = {
            time: Cn(),
            event: 4,
            data: Object.assign({}, l)
        }), l = l || {
            visible: 1,
            docWidth: 0,
            docHeight: 0,
            screenWidth: 0,
            screenHeight: 0,
            scrollX: 0,
            scrollY: 0,
            pointerX: 0,
            pointerY: 0,
            activityTime: 0,
            scrollTime: 0,
            pointerTime: void 0,
            moveX: void 0,
            moveY: void 0,
            moveTime: void 0,
            downX: void 0,
            downY: void 0,
            downTime: void 0,
            upX: void 0,
            upY: void 0,
            upTime: void 0,
            pointerPrevX: void 0,
            pointerPrevY: void 0,
            pointerPrevTime: void 0,
            modules: null
        }
    }

    function qn(t, e, n, a) {
        switch (t) {
            case 8:
                l.docWidth = e, l.docHeight = n;
                break;
            case 11:
                l.screenWidth = e, l.screenHeight = n;
                break;
            case 10:
                l.scrollX = e, l.scrollY = n, l.scrollTime = a;
                break;
            case 12:
                l.moveX = e, l.moveY = n, l.moveTime = a, Un(e, n, a);
                break;
            case 13:
                l.downX = e, l.downY = n, l.downTime = a, Un(e, n, a);
                break;
            case 14:
                l.upX = e, l.upY = n, l.upTime = a, Un(e, n, a);
                break;
            default:
                Un(e, n, a)
        }
        s = !0
    }

    function Un(t, e, n) {
        l.pointerPrevX = l.pointerX, l.pointerPrevY = l.pointerY, l.pointerPrevTime = l.pointerTime, l.pointerX = t, l.pointerY = e, l.pointerTime = n
    }

    function zn(t) {
        l.activityTime = t
    }

    function Fn(t, e) {
        bo() && t && "string" == typeof t && t.length < 255 && (d = e && "string" == typeof e && e.length < 255 ? {
            key: t,
            value: e
        } : {
            value: t
        }, Wr(24))
    }

    function Vn(t) {
        t in f || (f[t] = 0), t in h || (h[t] = 0)
    }

    function Bn(t) {
        Vn(t), f[t]++, h[t]++
    }

    function Jn(t, e) {
        null !== e && (Vn(t), f[t] += e, h[t] += e)
    }

    function Kn(t, e) {
        null !== e && !1 === isNaN(e) && (t in f || (f[t] = 0), (e > f[t] || 0 === f[t]) && (h[t] = e, f[t] = e))
    }

    function Gn(t, e, n) {
        return window.setTimeout(co(t), e, n)
    }

    function Zn(t) {
        return window.clearTimeout(t)
    }

    function Qn() {
        var t = Cn();
        p = {
            gap: t - g
        }, Wr(25), p.gap < 3e5 ? m = Gn(Qn, v) : cn && (Fn("clarity", "suspend"), _o(), ["mousemove", "touchstart"].forEach((function(t) {
            return lo(document, t, wo)
        })), ["resize", "scroll", "pageshow"].forEach((function(t) {
            return lo(window, t, wo)
        })))
    }

    function $n(t, e, n, a) {
        return new(n || (n = Promise))((function(i, r) {
            function o(t) {
                try {
                    c(a.next(t))
                } catch (t) {
                    r(t)
                }
            }

            function u(t) {
                try {
                    c(a.throw(t))
                } catch (t) {
                    r(t)
                }
            }

            function c(t) {
                var e;
                t.done ? i(t.value) : (e = t.value, e instanceof n ? e : new n((function(t) {
                    t(e)
                }))).then(o, u)
            }
            c((a = a.apply(t, e || [])).next())
        }))
    }

    function ta(t, e) {
        var n, a, i, r, o = {
            label: 0,
            sent: function() {
                if (1 & i[0]) throw i[1];
                return i[1]
            },
            trys: [],
            ops: []
        };
        return r = {
            next: u(0),
            throw: u(1),
            return: u(2)
        }, "function" == typeof Symbol && (r[Symbol.iterator] = function() {
            return this
        }), r;

        function u(u) {
            return function(c) {
                return function(u) {
                    if (n) throw new TypeError("Generator is already executing.");
                    for (; r && (r = 0, u[0] && (o = 0)), o;) try {
                        if (n = 1, a && (i = 2 & u[0] ? a.return : u[0] ? a.throw || ((i = a.return) && i.call(a), 0) : a.next) && !(i = i.call(a, u[1])).done) return i;
                        switch (a = 0, i && (u = [2 & u[0], i.value]), u[0]) {
                            case 0:
                            case 1:
                                i = u;
                                break;
                            case 4:
                                return o.label++, {
                                    value: u[1],
                                    done: !1
                                };
                            case 5:
                                o.label++, a = u[1], u = [0];
                                continue;
                            case 7:
                                u = o.ops.pop(), o.trys.pop();
                                continue;
                            default:
                                if (!((i = (i = o.trys).length > 0 && i[i.length - 1]) || 6 !== u[0] && 2 !== u[0])) {
                                    o = 0;
                                    continue
                                }
                                if (3 === u[0] && (!i || u[1] > i[0] && u[1] < i[3])) {
                                    o.label = u[1];
                                    break
                                }
                                if (6 === u[0] && o.label < i[1]) {
                                    o.label = i[1], i = u;
                                    break
                                }
                                if (i && o.label < i[2]) {
                                    o.label = i[2], o.ops.push(u);
                                    break
                                }
                                i[2] && o.ops.pop(), o.trys.pop();
                                continue
                        }
                        u = e.call(t, o)
                    } catch (t) {
                        u = [6, t], a = 0
                    } finally {
                        n = i = 0
                    }
                    if (5 & u[0]) throw u[1];
                    return {
                        value: u[0] ? u[1] : void 0,
                        done: !0
                    }
                }([u, c])
            }
        }
    }

    function ea(t) {
        return $n(this, void 0, void 0, (function() {
            var e, n;
            return ta(this, (function(a) {
                switch (a.label) {
                    case 0:
                        return a.trys.push([0, 3, , 4]), b ? (e = new ReadableStream({
                            start: function(e) {
                                return $n(this, void 0, void 0, (function() {
                                    return ta(this, (function(n) {
                                        return e.enqueue(t), e.close(), [2]
                                    }))
                                }))
                            }
                        }).pipeThrough(new TextEncoderStream).pipeThrough(new window.CompressionStream("gzip")), n = Uint8Array.bind, [4, new Response(e).arrayBuffer()]) : [3, 2];
                    case 1:
                        return [2, new(n.apply(Uint8Array, [void 0, a.sent()]))];
                    case 2:
                        return [3, 4];
                    case 3:
                        return a.sent(), [3, 4];
                    case 4:
                        return [2, null]
                }
            }))
        }))
    }

    function na(t, e) {
        aa(t, "string" == typeof e ? [e] : e)
    }

    function aa(t, e) {
        var n, a;
        if (bo() && t && e && "string" == typeof t && t.length < 255) {
            n = t in w ? w[t] : [];
            for (a = 0; a < e.length; a++) "string" == typeof e[a] && e[a].length < 255 && n.push(e[a]);
            w[t] = n
        }
    }

    function ia() {
        w = {}
    }

    function ra(t) {
        return $n(this, void 0, void 0, (function() {
            var e;
            return ta(this, (function(n) {
                switch (n.label) {
                    case 0:
                        return n.trys.push([0, 4, , 5]), crypto && t ? [4, crypto.subtle.digest("SHA-256", (new TextEncoder).encode(t))] : [3, 2];
                    case 1:
                        return e = n.sent(), [2, Array.prototype.map.call(new Uint8Array(e), (function(t) {
                            return ("00" + t.toString(16)).slice(-2)
                        })).join("")];
                    case 2:
                        return [2, ""];
                    case 3:
                        return [3, 5];
                    case 4:
                        return n.sent(), [2, ""];
                    case 5:
                        return [2]
                }
            }))
        }))
    }

    function oa(t) {
        return t && t.indexOf("@") > 0 ? "email" : "string"
    }

    function ua(t) {
        var e, n, a, i, r, o, u, c, l, s, d;
        try {
            for (o in n = (e = t && t.length > 0 ? t.split(/ (.*)/) : [""])[0].split(/\|(.*)/), a = parseInt(n[0]), i = n.length > 1 ? n[1] : "", r = e.length > 1 ? JSON.parse(e[1]) : {}, E[a] = {}, T[a] = {}, N[a] = {}, M[a] = i, r) switch (u = parseInt(o), c = r[o], l = 2, c.startsWith("~") ? l = 0 : c.startsWith("!") && (l = 4), l) {
                case 0:
                    s = c.slice(1), E[a][u] = da(s);
                    break;
                case 2:
                    T[a][u] = c;
                    break;
                case 4:
                    d = c.slice(1), N[a][u] = d
            }
        } catch (t) {
            _r(8, 1, t ? t.name : null)
        }
    }

    function ca(t) {
        return JSON.parse(JSON.stringify(t))
    }

    function la() {
        S.clear()
    }

    function sa(t, e, n) {
        var a, i = !1;
        t in k || (k[t] = {}, i = !0), a = N[t], 0 == Object.keys(a).length || e in k[t] && k[t][e] == n || (i = !0), k[t][e] = n, i && S.add(t)
    }

    function da(t) {
        for (var e, n, a, i, r = [], o = t.split("."); o.length > 0;) n = (e = o.shift()).indexOf("["), a = e.indexOf("{"), i = e.indexOf("}"), r.push({
            name: n > 0 ? e.slice(0, n) : a > 0 ? e.slice(0, a) : e,
            type: n > 0 ? 1 : a > 0 ? 2 : 3,
            condition: a > 0 ? e.slice(a + 1, i) : null
        });
        return r
    }

    function fa(t, e) {
        var n, a, i, r, o, u, c, l;
        if (void 0 === e && (e = window), 0 == t.length) return e;
        if (n = t.shift(), e && e[n.name]) {
            if (i = e[n.name], 1 !== n.type && ha(i, n.condition)) a = fa(t, i);
            else if (Array.isArray(i)) {
                for (r = [], o = 0, u = i; o < u.length; o++) ha(c = u[o], n.condition) && (l = fa(t, c)) && r.push(l);
                a = r
            }
            return a
        }
        return null
    }

    function ha(t, e) {
        if (e) {
            var n = e.split(":");
            return n.length > 1 ? t[n[0]] == n[1] : t[n[0]]
        }
        return !0
    }

    function pa(t, e) {
        try {
            return !!t[e]
        } catch (t) {
            return !1
        }
    }

    function ga(t) {
        try {
            var e = decodeURIComponent(t);
            return [e != t, e]
        } catch (t) {}
        return [!1, t]
    }

    function va(t, e) {
        var n, a, i, r, o, u, c;
        if (void 0 === e && (e = !1), pa(document, "cookie") && (a = document.cookie.split(";")))
            for (i = 0; i < a.length; i++)
                if ((r = a[i].split("=")).length > 1 && r[0] && r[0].trim() === t) {
                    for (u = (o = ga(r[1]))[0], c = o[1]; u;) u = (n = ga(c))[0], c = n[1];
                    return e ? c.endsWith("~1") ? c.substring(0, c.length - 2) : null : c
                }
        return null
    }

    function ma(t, e, n) {
        var a, i, r, o, u;
        if ((xn.track || "" == e) && (navigator && navigator.cookieEnabled || pa(document, "cookie"))) {
            a = function(t) {
                return encodeURIComponent(t)
            }(e), (i = new Date).setDate(i.getDate() + n), r = t + "=" + a + ";" + (i ? "expires=" + i.toUTCString() : "") + ";path=/";
            try {
                if (null === _) {
                    for (u = (o = location.hostname ? location.hostname.split(".") : []).length - 1; u >= 0; u--)
                        if (_ = "." + o[u] + (_ || ""), u < o.length - 1 && (document.cookie = r + ";domain=" + _, va(t) === e)) return;
                    _ = ""
                }
            } catch (t) {
                _ = ""
            }
            document.cookie = _ ? r + ";domain=" + _ : r
        }
    }

    function ya(t) {
        try {
            x && JSON.parse(t).forEach((function(t) {
                return x(t)
            }))
        } catch (t) {}
    }

    function ba(t, e, n) {
        xn.fraud && null !== t && n && n.length >= 5 && (C = {
            id: t,
            target: e,
            checksum: An(n, 28)
        }, D.includes(C.checksum) || (D.push(C.checksum), Mr(41)))
    }

    function wa(t) {
        var e, n, a = dr(t);
        a && (n = (e = a.value) && e.length >= 5 && xn.fraud && !R.includes(a.type) ? An(e, 28) : "", j.push({
            time: Cn(t),
            event: 42,
            data: {
                target: dr(t),
                type: a.type,
                value: e,
                checksum: n
            }
        }), xr(hr.bind(this, 42)))
    }

    function ka() {
        j = []
    }

    function Sa(t) {
        var e, n, a = {
            x: 0,
            y: 0
        };
        if (t && t.offsetParent)
            do {
                n = null === (e = t.offsetParent) ? Ji(t.ownerDocument) : null, a.x += t.offsetLeft, a.y += t.offsetTop, t = n || e
            } while (t);
        return a
    }

    function Ea(t, e, n) {
        var a, i, r, o, u, c, l, s, d, f, h = Ji(e),
            p = h && h.contentDocument ? h.contentDocument.documentElement : document.documentElement,
            g = "pageX" in n ? Math.round(n.pageX) : "clientX" in n ? Math.round(n.clientX + p.scrollLeft) : null,
            v = "pageY" in n ? Math.round(n.pageY) : "clientY" in n ? Math.round(n.clientY + p.scrollTop) : null;
        h && (a = Sa(h), g = g ? g + Math.round(a.x) : g, v = v ? v + Math.round(a.y) : v), r = function(t) {
            for (; t && t !== document;) {
                if (t.nodeType === Node.ELEMENT_NODE) {
                    var e = t;
                    if ("A" === e.tagName) return e
                }
                t = t.parentNode
            }
            return null
        }(i = dr(n)), o = Na(i), 0 === n.detail && o && (g = Math.round(o.x + o.w / 2), v = Math.round(o.y + o.h / 2)), u = function(t, e, n, a) {
            if (!a) return {
                eX: 0,
                eY: 0
            };
            for (var i = a, r = t, o = Math.max(Math.floor((e - i.x) / i.w * 32767), 0), u = Math.max(Math.floor((n - i.y) / i.h * 32767), 0), c = 0;
                (o > 32767 || u > 32767) && r.parentElement && c < 10;) c++, (i = Na(r = r.parentElement)) && (o = Math.max(Math.floor((e - i.x) / i.w * 32767), 0), u = Math.max(Math.floor((n - i.y) / i.h * 32767), 0));
            return {
                eX: o,
                eY: u
            }
        }(i, g, v, o), c = u.eX, l = u.eY, null !== g && null !== v && (s = function(t) {
            var e, n, a = null,
                i = !1;
            return t && (e = t.textContent || String(t.value || "") || t.alt) && (i = (a = (n = e.replace(/\s+/g, " ").trim()).substring(0, 25)).length === n.length), {
                text: a,
                isFullText: i ? 1 : 0
            }
        }(i), H.push({
            time: Cn(n),
            event: t,
            data: {
                target: i,
                x: g,
                y: v,
                eX: c,
                eY: l,
                button: n.button,
                reaction: (d = i, f = Ta(d, "tagName"), X.includes(f) ? 0 : 1),
                context: Ma(r),
                text: s.text,
                link: r ? r.href : null,
                hash: null,
                trust: n.isTrusted ? 1 : 0,
                isFullText: s.isFullText,
                w: o ? o.w : 0,
                h: o ? o.h : 0,
                tag: Ta(i, "tagName").substring(0, 10),
                class: Ta(i, "className").substring(0, 50),
                id: Ta(i, "id").substring(0, 25),
                source: xn.diagnostics && !n.isTrusted ? _a() : 0
            }
        }), xr(hr.bind(this, t)))
    }

    function Ta(t, e) {
        var n;
        return t.nodeType === Node.ELEMENT_NODE && "string" == typeof(n = null == t ? void 0 : t[e]) ? null == n ? void 0 : n.toLowerCase() : ""
    }

    function Na(t) {
        var e, n, a, i, r, o = null,
            u = t.ownerDocument || document,
            c = u.documentElement,
            l = u.defaultView || window;
        return "function" == typeof t.getBoundingClientRect && (e = t.getBoundingClientRect()) && e.width > 0 && e.height > 0 && (n = "pageXOffset" in l ? l.pageXOffset : c.scrollLeft, a = "pageYOffset" in l ? l.pageYOffset : c.scrollTop, o = {
            x: Math.floor(e.left + n),
            y: Math.floor(e.top + a),
            w: Math.floor(e.width),
            h: Math.floor(e.height)
        }, (i = Ji(u)) && (r = Sa(i), o.x += Math.round(r.x), o.y += Math.round(r.y))), o
    }

    function Ma(t) {
        if (t && t.hasAttribute("target")) switch (t.getAttribute("target")) {
            case "_blank":
                return 1;
            case "_parent":
                return 2;
            case "_top":
                return 3
        }
        return 0
    }

    function _a() {
        var t, e, n, a, i, r;
        _a.dn = 1;
        try {
            for (t = (new Error).stack || "", e = location.origin, n = 4, a = 0, i = t.split("\n"); a < i.length; a++)(r = i[a]).includes("://") ? n = !r.includes("extension") && r.includes(e) ? 1 : 2 : (r.includes("eval") || r.includes("Function") || r.includes("<a") || W.test(r)) && (n = 3);
            return n
        } catch (t) {
            return 4
        }
    }

    function Oa() {
        H = []
    }

    function xa(t, e) {
        q.push({
            time: Cn(e),
            event: 38,
            data: {
                target: dr(e),
                action: t
            }
        }), xr(hr.bind(this, 38))
    }

    function Ia() {
        q = []
    }

    function Da(t) {
        var e, n, a, i = dr(t),
            r = $i(i);
        if (i && i.type && r) {
            switch (e = i.value, n = i.type, i.type) {
                case "radio":
                case "checkbox":
                    e = i.checked ? "true" : "false"
            }
            a = {
                target: i,
                value: e,
                type: n,
                trust: t.isTrusted ? 1 : 0
            }, z.length > 0 && z[z.length - 1].data.target === a.target && z.pop(), z.push({
                time: Cn(t),
                event: 27,
                data: a
            }), Zn(U), U = Gn(Aa, 750, 27)
        }
    }

    function Ca(t) {
        "Enter" === t.key && !t.repeat && z.length > 0 && (Zn(U), Aa(27))
    }

    function Aa(t) {
        xr(hr.bind(this, t))
    }

    function Pa() {
        z = []
    }

    function Ra(t, e, n) {
        var a, i = Ji(e),
            r = i && i.contentDocument ? i.contentDocument.documentElement : document.documentElement,
            o = "pageX" in n ? Math.round(n.pageX) : "clientX" in n ? Math.round(n.clientX + r.scrollLeft) : null,
            u = "pageY" in n ? Math.round(n.pageY) : "clientY" in n ? Math.round(n.clientY + r.scrollTop) : null;
        i && (a = Sa(i), o = o ? o + Math.round(a.x) : o, u = u ? u + Math.round(a.y) : u), null !== o && null !== u && Ya({
            time: Cn(n),
            event: t,
            data: {
                target: dr(n),
                x: o,
                y: u
            }
        })
    }

    function La(t, e, n) {
        var a, i, r, o, u, c, l = Ji(e),
            s = l && l.contentDocument ? l.contentDocument.documentElement : document.documentElement,
            d = n.changedTouches,
            f = Cn(n);
        if (d)
            for (a = 0; a < d.length; a++) {
                switch (r = "clientX" in (i = d[a]) ? Math.round(i.clientX + s.scrollLeft) : null, o = "clientY" in i ? Math.round(i.clientY + s.scrollTop) : null, r = r && l ? r + Math.round(l.offsetLeft) : r, o = o && l ? o + Math.round(l.offsetTop) : o, u = "identifier" in i ? i.identifier : void 0, t) {
                    case 17:
                        0 === K.size && (B = !0, J = u), K.add(u);
                        break;
                    case 18:
                    case 20:
                        K.delete(u)
                }
                c = B && J === u, null !== r && null !== o && Ya({
                    time: f,
                    event: t,
                    data: {
                        target: dr(n),
                        x: r,
                        y: o,
                        id: u,
                        isPrimary: c
                    }
                }), 20 !== t && 18 !== t || J === u && (B = !1)
            }
    }

    function Ya(t) {
        var e, n;
        switch (t.event) {
            case 12:
            case 15:
            case 19:
                (n = (e = F.length) > 1 ? F[e - 2] : null) && function(t, e) {
                    var n = t.data.x - e.data.x,
                        a = t.data.y - e.data.y,
                        i = Math.sqrt(n * n + a * a),
                        r = e.time - t.time,
                        o = e.data.target === t.data.target,
                        u = void 0 === e.data.id || e.data.id === t.data.id;
                    return e.event === t.event && o && i < 20 && r < 25 && u
                }(n, t) && F.pop(), F.push(t), Zn(V), V = Gn(ja, 500, t.event);
                break;
            default:
                F.push(t), ja(t.event)
        }
    }

    function ja(t) {
        xr(hr.bind(this, t))
    }

    function Xa() {
        F = []
    }

    function Wa(t, e) {
        var n = 0,
            a = null,
            i = null;

        function r() {
            var r, o, u, c = this,
                l = [];
            for (r = 0; r < arguments.length; r++) l[r] = arguments[r];
            if (u = (o = performance.now()) - n, 0 !== n && u < e) {
                if (i = l, a) return;
                a = setTimeout((function() {
                    n = performance.now(), t.apply(c, i), i = null, a = null
                }), e - u)
            } else n = o, t.apply(this, l)
        }
        return r.cleanup = function() {
            a && (clearTimeout(a), a = null, i = null)
        }, r
    }

    function Ha() {
        var t = document.documentElement;
        G = {
            width: t && "clientWidth" in t ? Math.min(t.clientWidth, window.innerWidth) : window.innerWidth,
            height: t && "clientHeight" in t ? Math.min(t.clientHeight, window.innerHeight) : window.innerHeight
        }, Q ? (Zn(Z), Z = Gn(qa, 500, 11)) : (hr(11), Q = !0)
    }

    function qa(t) {
        xr(hr.bind(this, t))
    }

    function Ua() {
        G = null, Zn(Z), $.cleanup()
    }

    function za(t) {
        var e, n, a, i, r, o, u, c, l, s, d, f, h, p, g, v, m;
        if (void 0 === t && (t = null), e = window, n = document.documentElement, a = t ? dr(t) : n) {
            if (a && a.nodeType === Node.DOCUMENT_NODE && (e = (i = Ji(a)) ? i.contentWindow : e, a = n = a.documentElement), r = a === n && "pageXOffset" in e ? Math.round(e.pageXOffset) : Math.round(a.scrollLeft), o = a === n && "pageYOffset" in e ? Math.round(e.pageYOffset) : Math.round(a.scrollTop), u = window.innerWidth, d = (c = window.innerHeight) - (s = u > c ? .15 * c : .2 * c), f = Fa(l = u / 3, s), h = Fa(l, d), p = t && t.isTrusted ? 1 : 0, g = {
                    time: Cn(t),
                    event: 10,
                    data: {
                        target: a,
                        x: r,
                        y: o,
                        top: f,
                        bottom: h,
                        trust: p
                    }
                }, null === t && 0 === r && 0 === o || null === r || null === o) return et = f, void(nt = h);
            (m = (v = tt.length) > 1 ? tt[v - 2] : null) && function(t, e) {
                var n = t.data.x - e.data.x,
                    a = t.data.y - e.data.y;
                return n * n + a * a < 400 && e.time - t.time < 50
            }(m, g) && tt.pop(), tt.push(g), Zn(at), at = Gn(Va, 500, 10)
        }
    }

    function Fa(t, e) {
        var n, a, i;
        return "caretPositionFromPoint" in document ? i = null === (n = document.caretPositionFromPoint(t, e)) || void 0 === n ? void 0 : n.offsetNode : "caretRangeFromPoint" in document && (i = null === (a = document.caretRangeFromPoint(t, e)) || void 0 === a ? void 0 : a.startContainer), i || (i = document.elementFromPoint(t, e)), i && i.nodeType === Node.TEXT_NODE && (i = i.parentNode), i
    }

    function Va(t) {
        xr(hr.bind(this, t))
    }

    function Ba() {
        var t, e, n, a;
        et && qr(31, null === (t = null == (n = fr(et, null)) ? void 0 : n.hash) || void 0 === t ? void 0 : t.join(".")), nt && qr(32, null === (e = null == (a = fr(nt, null)) ? void 0 : a.hash) || void 0 === e ? void 0 : e.join("."))
    }

    function Ja(t) {
        var e, n = (t.nodeType === Node.DOCUMENT_NODE ? t : document).getSelection();
        null !== n && (null === n.anchorNode && null === n.focusNode || n.anchorNode === n.focusNode && n.anchorOffset === n.focusOffset || (e = rt.start ? rt.start : null, null !== ot && null !== rt.start && e !== n.anchorNode && (Zn(ut), Ka(21)), rt = {
            start: n.anchorNode,
            startOffset: n.anchorOffset,
            end: n.focusNode,
            endOffset: n.focusOffset
        }, ot = n, Zn(ut), ut = Gn(Ka, 500, 21)))
    }

    function Ka(t) {
        xr(hr.bind(this, t))
    }

    function Ga() {
        ot = null, rt = {
            start: 0,
            startOffset: 0,
            end: 0,
            endOffset: 0
        }
    }

    function Za(t) {
        ct.push({
            time: Cn(t),
            event: 39,
            data: {
                target: dr(t)
            }
        }), xr(hr.bind(this, 39))
    }

    function Qa() {
        ct = []
    }

    function $a(t) {
        lt = {
            name: t.type,
            persisted: t.persisted ? 1 : 0
        }, hr(26, Cn(t)), _o()
    }

    function ti() {
        lt = null
    }

    function ei(t) {
        if (void 0 === t && (t = null), "visibilityState" in document) {
            var e = "visible" === document.visibilityState ? 1 : 0;
            st = {
                visible: e
            }, hr(28, Cn(t))
        }
    }

    function ni() {
        st = null
    }

    function ai() {
        dt = null
    }

    function ii(t) {
        dt = {
            focused: t
        }, hr(50)
    }

    function ri(t) {
        t && t.persisted && (Mo(), _r(11, 0))
    }

    function oi(t) {
        var e, n, a, i = [],
            r = {},
            o = 0,
            u = null;
        for (e = 0; e < t.length; e++) "string" == typeof t[e] ? (a = r[n = t[e]] || -1) >= 0 ? u ? u.push(a) : (u = [a], i.push(u), o++) : (u = null, i.push(n), r[n] = o++) : (u = null, i.push(t[e]), o++);
        return i
    }

    function ui(t) {
        xn.lean && xn.lite || null == t || (t.__clr = t.__clr || {}, t.CSSStyleSheet && t.CSSStyleSheet.prototype && (ci(t, "replace", 1), ci(t, "replaceSync", 2)))
    }

    function ci(t, e, n) {
        void 0 === t.__clr[e] && (t.__clr[e] = t.CSSStyleSheet.prototype[e], t.CSSStyleSheet.prototype[e] = function() {
            return bo() && bt.includes(this[gt]) && fi(Cn(), this[gt], n, arguments[0]), t.__clr[e].apply(this, arguments)
        })
    }

    function li() {
        ui(window)
    }

    function si(t, e) {
        var n, a, i, r, o, u, c;
        if ((!xn.lean || !xn.lite) && (yt.includes(t) || (yt.push(t), t.defaultView && ui(t.defaultView)), e = e || Cn(), null == t ? void 0 : t.adoptedStyleSheets)) {
            for (n = [], a = 0, i = t.adoptedStyleSheets; a < i.length; a++)(r = i[a])[gt] && bt.includes(r[gt]) || (r[gt] = ao(), bt.push(r[gt]), fi(e, r[gt], 0), fi(e, r[gt], 2, Wi(r))), n.push(r[gt]);
            o = Fi(t, !0), vt[o] || (vt[o] = []), u = n, c = vt[o], u.length === c.length && u.every((function(t, e) {
                return t === c[e]
            })) || (function(t, e, n, a) {
                pt.push({
                    time: t,
                    event: 45,
                    data: {
                        id: e,
                        operation: 3,
                        newIds: a
                    }
                }), bi(45)
            }(e, t == document ? -1 : Fi(t), 0, n), vt[o] = n, mt[o] = e)
        }
    }

    function di() {
        pt = [], ht = []
    }

    function fi(t, e, n, a) {
        ht.push({
            time: t,
            event: 46,
            data: {
                id: e,
                operation: n,
                cssRules: a
            }
        }), bi(46)
    }

    function hi() {
        wt = []
    }

    function pi(t, e, n, a, i, r, o) {
        wt.push({
            time: t,
            event: 44,
            data: {
                id: e,
                operation: n,
                keyFrames: a,
                timing: i,
                targetId: r,
                timeline: o
            }
        }), bi(44)
    }

    function gi(t) {
        var e = Animation.prototype[t];
        "function" == typeof e && (Animation.prototype[t] = function() {
            return vi(this, t), e.apply(this, arguments)
        })
    }

    function vi(t, e) {
        var n, a, i, r, o;
        if (bo() && (a = (null == (n = t.effect) ? void 0 : n.target) ? Fi(n.target) : null, n && null !== a && !n.pseudoElement && n.getKeyframes && n.getTiming && (t[Et] || (t[Et] = ao(), t[Tt] = 0, i = n.getKeyframes(), r = n.getTiming(), pi(Cn(), t[Et], 0, JSON.stringify(i), JSON.stringify(r), a)), t[Tt]++ < Nt))) {
            switch (o = null, e) {
                case "play":
                    o = 1;
                    break;
                case "pause":
                    o = 2;
                    break;
                case "cancel":
                    o = 3;
                    break;
                case "finish":
                    o = 4;
                    break;
                case "commitStyles":
                    o = 5
            }
            o && pi(Cn(), t[Et], o)
        }
    }

    function mi(t) {
        _t.has(t) || (_t.add(t), Mt.push(t), xr(bi.bind(this, 51)))
    }

    function yi() {
        Mt.length = 0
    }

    function bi(t, e, n) {
        return void 0 === e && (e = null), void 0 === n && (n = null), $n(this, void 0, void 0, (function() {
            var a, i, r, o, u, c, l, s, d, f, h, p, g, v, m, y, b, w, k, S, E, T, N, M, _, O, x, I, D, C, A, P;
            return ta(this, (function(R) {
                switch (R.label) {
                    case 0:
                        switch (a = n || Cn(), i = [a, t], t) {
                            case 8:
                                return [3, 1];
                            case 7:
                                return [3, 2];
                            case 45:
                            case 46:
                                return [3, 3];
                            case 44:
                                return [3, 4];
                            case 5:
                            case 6:
                                return [3, 5];
                            case 51:
                                return [3, 12]
                        }
                        return [3, 13];
                    case 1:
                        return r = Ot, i.push(r.width, r.height), qn(t, r.width, r.height), wr(i), [3, 13];
                    case 2:
                        for (o = 0, u = oe; o < u.length; o++) c = u[o], (i = [c.time, 7]).push(c.data.id, c.data.interaction, c.data.visibility, c.data.name), wr(i, !1);
                        return sr(), [3, 13];
                    case 3:
                        for (l = 0, s = pt; l < s.length; l++) g = s[l], (i = [g.time, g.event]).push(g.data.id, g.data.operation, g.data.newIds), wr(i);
                        for (d = 0, f = ht; d < f.length; d++) g = f[d], (i = [g.time, g.event]).push(g.data.id, g.data.operation, g.data.cssRules), wr(i, !1);
                        return di(), [3, 13];
                    case 4:
                        for (h = 0, p = wt; h < p.length; h++) g = p[h], (i = [g.time, g.event]).push(g.data.id, g.data.operation, g.data.keyFrames, g.data.timing, g.data.timeline, g.data.targetId), wr(i);
                        return hi(), [3, 13];
                    case 5:
                        if (2 === Dr(e)) return [3, 13];
                        if (v = function() {
                                var t, e, n, a;
                                for (t = [], e = 0, n = Bt; e < n.length; e++)(a = n[e]) in Vt && t.push(Vt[a]);
                                return Bt = [], t
                            }(), !(v.length > 0)) return [3, 11];
                        m = 0, y = v, R.label = 6;
                    case 6:
                        return m < y.length ? (b = y[m], 0 !== (w = Dr(e)) ? [3, 8] : [4, Pr(e)]) : [3, 10];
                    case 7:
                        w = R.sent(), R.label = 8;
                    case 8:
                        if (2 === w) return [3, 10];
                        for (k = b.data, S = b.metadata.active, E = b.metadata.suspend, T = b.metadata.privacy, N = function(t) {
                                var e = t.metadata.privacy;
                                return "*T" === t.data.tag && !(0 === e || 1 === e)
                            }(b), M = 0, _ = S ? ["tag", "attributes", "value"] : ["tag"]; M < _.length; M++)
                            if (k[O = _[M]] || "" === k[O]) switch (O) {
                                case "tag":
                                    x = wi(b), I = N ? -1 : 1, i.push(b.id * I), b.parent && S && (i.push(b.parent), b.previous && i.push(b.previous)), i.push(E ? "*M" : k[O]), x && 2 === x.length && i.push("#" + x[0].toString(36) + "." + x[1].toString(36));
                                    break;
                                case "attributes":
                                    for (D in k[O]) void 0 !== k[O][D] && i.push(ki(D, k[O][D], T, k.tag));
                                    break;
                                case "value":
                                    ba(b.metadata.fraud, b.id, k[O]), i.push(Pn(k[O], k.tag, T, N))
                            }
                        R.label = 9;
                    case 9:
                        return m++, [3, 6];
                    case 10:
                        6 === t && zn(a), wr(oi(i), !xn.lean), R.label = 11;
                    case 11:
                        return [3, 13];
                    case 12:
                        for (C = 0, A = Mt; C < A.length; C++) P = A[C], wr([a, 51, P]);
                        return yi(), [3, 13];
                    case 13:
                        return [2]
                }
            }))
        }))
    }

    function wi(t) {
        if (null !== t.metadata.size && 0 === t.metadata.size.length) {
            var e = Qi(t.id);
            if (e) return [Math.floor(100 * e.offsetWidth), Math.floor(100 * e.offsetHeight)]
        }
        return t.metadata.size
    }

    function ki(t, e, n, a) {
        return "href" === t && "LINK" === a ? t + "=" + e : t + "=" + Pn(e, 0 === t.indexOf("data-") ? "data-" : t, n)
    }

    function Si() {
        Ot = null
    }

    function Ei() {
        var t = document.body,
            e = document.documentElement,
            n = t ? t.clientWidth : null,
            a = t ? t.scrollWidth : null,
            i = t ? t.offsetWidth : null,
            r = e ? e.clientWidth : null,
            o = e ? e.scrollWidth : null,
            u = e ? e.offsetWidth : null,
            c = Math.max(n, a, i, r, o, u),
            l = t ? t.clientHeight : null,
            s = t ? t.scrollHeight : null,
            d = t ? t.offsetHeight : null,
            f = e ? e.clientHeight : null,
            h = e ? e.scrollHeight : null,
            p = e ? e.offsetHeight : null,
            g = Math.max(l, s, d, f, h, p);
        null !== Ot && c === Ot.width && g === Ot.height || null === c || null === g || (Ot = {
            width: c,
            height: g
        }, bi(8))
    }

    function Ti(t, e, n, a) {
        return $n(this, void 0, void 0, (function() {
            var i, r, o, u, c;
            return ta(this, (function(l) {
                switch (l.label) {
                    case 0:
                        i = [t], l.label = 1;
                    case 1:
                        if (!(i.length > 0)) return [3, 4];
                        for (r = i.shift(), o = r.firstChild; o;) i.push(o), o = o.nextSibling;
                        return 0 !== (u = Dr(e)) ? [3, 3] : [4, Pr(e)];
                    case 2:
                        u = l.sent(), l.label = 3;
                    case 3:
                        return 2 === u ? [3, 4] : ((c = Yi(r, n, a)) && i.push(c), [3, 1]);
                    case 4:
                        return [2]
                }
            }))
        }))
    }

    function Ni() {
        xt = new Set, Ct = [], At = null, Rt = 0, Lt = {}, Yt = new WeakMap, Ai(window)
    }

    function Mi(t) {
        var e = Cn();
        ! function(t, e) {
            var n, a;
            6 in y ? e - (a = (n = y[6])[n.length - 1])[0] > 100 ? y[6].push([e, 0]) : a[1] = e - a[0] : y[6] = [
                [e, 0]
            ]
        }(0, e), It.push({
            time: e,
            mutations: t
        }), xr(Oi, 1).then((function() {
            Gn(Ei), co(or)()
        }))
    }

    function _i(t, e, n, a) {
        return $n(this, void 0, void 0, (function() {
            var i, r, o;
            return ta(this, (function(u) {
                switch (u.label) {
                    case 0:
                        return 0 !== (i = Dr(t)) ? [3, 2] : [4, Pr(t)];
                    case 1:
                        i = u.sent(), u.label = 2;
                    case 2:
                        if (2 === i) return [2];
                        switch (r = e.target, o = xn.throttleDom ? function(t, e, n, a) {
                            var i, r, o, u, c, l = t.target ? $i(t.target.parentNode) : null;
                            return l && "HTML" !== l.data.tag && (i = a > Rt, o = (r = $i(t.target)) && r.selector ? r.selector.join() : t.target.nodeName, u = [l.selector ? l.selector.join() : "", o, t.attributeName, xi(t.addedNodes), xi(t.removedNodes)].join(), Lt[u] = u in Lt ? Lt[u] : [0, n], c = Lt[u], !1 === i && c[0] >= 10 && Ii(c[2], 2, e, a), c[0] = i ? c[1] === n ? c[0] : c[0] + 1 : 1, c[1] = n, c[0] >= 10) ? (c[2] = t.removedNodes, n > a + 3e3 ? t.type : (Dt[u] = {
                                mutation: t,
                                timestamp: a
                            }, "throttle")) : t.type
                        }(e, t, n, a) : e.type, o && r && r.ownerDocument && zi(r.ownerDocument), o && r && r.nodeType == Node.DOCUMENT_FRAGMENT_NODE && r.host && zi(r), o) {
                            case "attributes":
                                jt.includes(e.attributeName) || Yi(r, 3, a);
                                break;
                            case "characterData":
                                Yi(r, 4, a);
                                break;
                            case "childList":
                                Ii(e.addedNodes, 1, t, a), Ii(e.removedNodes, 2, t, a)
                        }
                        return [2]
                }
            }))
        }))
    }

    function Oi() {
        return $n(this, void 0, void 0, (function() {
            var t, e, n, a, i, r, o, u, c, l, s;
            return ta(this, (function(d) {
                switch (d.label) {
                    case 0:
                        Cr(t = {
                            id: Jr(),
                            cost: 3
                        }), d.label = 1;
                    case 1:
                        if (!(It.length > 0)) return [3, 7];
                        e = It.shift(), n = Cn(), a = 0, i = e.mutations, d.label = 2;
                    case 2:
                        return a < i.length ? (r = i[a], [4, _i(t, r, n, e.time)]) : [3, 5];
                    case 3:
                        d.sent(), d.label = 4;
                    case 4:
                        return a++, [3, 2];
                    case 5:
                        return [4, bi(6, t, e.time)];
                    case 6:
                        return d.sent(), [3, 1];
                    case 7:
                        o = !1, u = 0, c = Object.keys(Dt), d.label = 8;
                    case 8:
                        return u < c.length ? (l = c[u], s = Dt[l], delete Dt[l], [4, _i(t, s.mutation, Cn(), s.timestamp)]) : [3, 11];
                    case 9:
                        d.sent(), o = !0, d.label = 10;
                    case 10:
                        return u++, [3, 8];
                    case 11:
                        return Object.keys(Dt).length > 0 && (Pt && Zn(Pt), Pt = Gn((function() {
                            xr(Oi, 1)
                        }), 33)), 0 === Object.keys(Dt).length && o ? [4, bi(6, t, Cn())] : [3, 13];
                    case 12:
                        d.sent(), d.label = 13;
                    case 13:
                        return function() {
                            var t, e, n, a = Cn();
                            for (Object.keys(Lt).length > 1e4 && (Lt = {}, Bn(38)), t = 0, e = Object.keys(Lt); t < e.length; t++) n = e[t], a > Lt[n][1] + 3e4 && delete Lt[n]
                        }(), Ar(t), [2]
                }
            }))
        }))
    }

    function xi(t) {
        var e, n = [];
        for (e = 0; t && e < t.length; e++) n.push(t[e].nodeName);
        return n.join()
    }

    function Ii(t, e, n, a) {
        return $n(this, void 0, void 0, (function() {
            var i, r, o, u;
            return ta(this, (function(c) {
                switch (c.label) {
                    case 0:
                        i = t ? t.length : 0, r = 0, c.label = 1;
                    case 1:
                        return r < i ? (o = t[r], 1 !== e ? [3, 2] : (Ti(o, n, e, a), [3, 5])) : [3, 6];
                    case 2:
                        return 0 !== (u = Dr(n)) ? [3, 4] : [4, Pr(n)];
                    case 3:
                        u = c.sent(), c.label = 4;
                    case 4:
                        if (2 === u) return [3, 6];
                        Yi(o, e, a), c.label = 5;
                    case 5:
                        return r++, [3, 1];
                    case 6:
                        return [2]
                }
            }))
        }))
    }

    function Di(t) {
        return Ct.includes(t) || Ct.push(t), At && Zn(At), At = Gn((function() {
            ! function() {
                var t, e, n, a;
                for (t = 0, e = Ct; t < e.length; t++)
                    if (n = e[t]) {
                        if ((a = n.nodeType === Node.DOCUMENT_FRAGMENT_NODE) && tr(n)) continue;
                        Ci(n, a ? "childList" : "characterData")
                    }
                Ct = []
            }()
        }), 33), t
    }

    function Ci(t, e) {
        co(Mi)([{
            addedNodes: [t],
            attributeName: null,
            attributeNamespace: null,
            nextSibling: null,
            oldValue: null,
            previousSibling: null,
            removedNodes: [],
            target: t,
            type: e
        }])
    }

    function Ai(t) {
        if (null != t && (t.__clr = t.__clr || {}, Pi(t, "CSSStyleSheet", "InsertRule", "insertRule", (function() {
                return this.ownerNode
            })), Pi(t, "CSSStyleSheet", "DeleteRule", "deleteRule", (function() {
                return this.ownerNode
            })), Pi(t, "CSSMediaRule", "MediaInsertRule", "insertRule", (function() {
                return this.parentStyleSheet.ownerNode
            })), Pi(t, "CSSMediaRule", "MediaDeleteRule", "deleteRule", (function() {
                return this.parentStyleSheet.ownerNode
            })), "Element" in t && t.Element && t.Element.prototype && void 0 === t.__clr.AttachShadow)) {
            t.__clr.AttachShadow = t.Element.prototype.attachShadow;
            try {
                t.Element.prototype.attachShadow = function() {
                    return bo() ? Di(t.__clr.AttachShadow.apply(this, arguments)) : t.__clr.AttachShadow.apply(this, arguments)
                }
            } catch (e) {
                t.__clr.AttachShadow = null
            }
        }
    }

    function Pi(t, e, n, a, i) {
        e in t && t[e] && t[e].prototype && void 0 === t.__clr[n] && (t.__clr[n] = t[e].prototype[a], t[e].prototype[a] = function() {
            return bo() && Di(i.call(this)), t.__clr[n].apply(this, arguments)
        })
    }

    function Ri(t) {
        var e, n, a, i;
        for (e = 0, n = Object.keys(t); e < n.length; e++) {
            if (i = t[a = n[e]], "@type" === a && "string" == typeof i) switch (i = (i = i.toLowerCase()).includes("article") || i.includes("posting") ? "article" : i) {
                case "article":
                case "recipe":
                    qr(5, t[a]), qr(8, t.creator), qr(18, t.headline);
                    break;
                case "product":
                    qr(5, t[a]), qr(10, t.name), qr(12, t.sku), t.brand && qr(6, t.brand.name);
                    break;
                case "aggregaterating":
                    t.ratingValue && (Kn(11, Li(t.ratingValue, 100)), Kn(18, Li(t.bestRating)), Kn(19, Li(t.worstRating))), Kn(12, Li(t.ratingCount)), Kn(17, Li(t.reviewCount));
                    break;
                case "offer":
                    qr(7, t.availability), qr(14, t.itemCondition), qr(13, t.priceCurrency), qr(12, t.sku), Kn(13, Li(t.price));
                    break;
                case "brand":
                    qr(6, t.name)
            }
            null !== i && "object" == typeof i && Ri(i)
        }
    }

    function Li(t, e) {
        if (void 0 === e && (e = 1), null !== t) switch (typeof t) {
            case "number":
                return Math.round(t * e);
            case "string":
                return Math.round(parseFloat(t.replace(Xt, "")) * e)
        }
        return null
    }

    function Yi(t, e, n) {
        var a, i, r, o, u, c, l, s, d, f, h, p, g, v, m, y, b, w, k, S, E, T, N, M, _ = null;
        if (2 === e && !1 === tr(t)) return _;
        switch (0 !== e && t.nodeType === Node.TEXT_NODE && t.parentElement && "STYLE" === t.parentElement.tagName && (t = t.parentNode), i = tr(t) ? Bi : Vi, r = t.parentElement ? t.parentElement : null, o = t.ownerDocument !== document, t.nodeType) {
            case Node.DOCUMENT_TYPE_NODE:
                i(t, r = o && t.parentNode ? Ji(t.parentNode) : r, {
                    tag: (o ? "iframe:" : "") + "*D",
                    attributes: {
                        name: (u = t).name ? u.name : "HTML",
                        publicId: u.publicId,
                        systemId: u.systemId
                    }
                }, e);
                break;
            case Node.DOCUMENT_NODE:
                t === document && zi(document), si(t, n), ji(t);
                break;
            case Node.DOCUMENT_FRAGMENT_NODE:
                (c = t).host && (zi(c), "function" == typeof c.constructor && c.constructor.toString().includes("[native code]") ? (ji(c), l = {
                    tag: "*S",
                    attributes: {
                        style: ""
                    }
                }, i(t, c.host, l, e)) : i(t, c.host, {
                    tag: "*P",
                    attributes: {}
                }, e), si(t, n));
                break;
            case Node.TEXT_NODE:
                r = r || t.parentNode, (i === Bi || r && tr(r) && "STYLE" !== r.tagName && "NOSCRIPT" !== r.tagName) && i(t, r, {
                    tag: "*T",
                    value: t.nodeValue
                }, e);
                break;
            case Node.ELEMENT_NODE:
                switch (d = (s = t).tagName, f = function(t) {
                    var e, n, a = {},
                        i = t.attributes;
                    if (i && i.length > 0)
                        for (e = 0; e < i.length; e++) n = i[e].name, Wt.includes(n) || (a[n] = i[e].value);
                    return "INPUT" === t.tagName && !("value" in a) && t.value && (a.value = t.value), a
                }(s), r = t.parentElement ? t.parentElement : t.parentNode ? t.parentNode : null, "http://www.w3.org/2000/svg" === s.namespaceURI && (d = "svg:" + d), d) {
                    case "HTML":
                        i(t, r = o && r ? Ji(r) : r, {
                            tag: (o ? "iframe:" : "") + d,
                            attributes: f
                        }, e);
                        break;
                    case "SCRIPT":
                        if ("type" in f && "application/ld+json" === f.type) try {
                            Ri(JSON.parse(s.text.replace(Ht, "")))
                        } catch (t) {}
                        break;
                    case "NOSCRIPT":
                        i(t, r, {
                            tag: d,
                            attributes: {},
                            value: ""
                        }, e);
                        break;
                    case "META":
                        if ((h = "property" in f ? "property" : "name" in f ? "name" : null) && "content" in f) switch (p = f.content, f[h]) {
                            case "og:title":
                                qr(20, p);
                                break;
                            case "og:type":
                                qr(19, p);
                                break;
                            case "generator":
                                qr(21, p)
                        }
                        break;
                    case "HEAD":
                        g = {
                            tag: d,
                            attributes: f
                        }, v = o && (null === (a = t.ownerDocument) || void 0 === a ? void 0 : a.location) ? t.ownerDocument.location : location, g.attributes["*B"] = v.protocol + "//" + v.host + v.pathname, i(t, r, g, e);
                        break;
                    case "BASE":
                        (m = $i(t.parentElement)) && ((y = document.createElement("a")).href = f.href, m.data.attributes["*B"] = y.protocol + "//" + y.host + y.pathname);
                        break;
                    case "STYLE":
                        i(t, r, {
                            tag: d,
                            attributes: f,
                            value: (T = s, N = T.textContent ? T.textContent.trim() : "", M = T.dataset ? Object.keys(T.dataset).length : 0, (0 === N.length || M > 0 || T.id.length > 0) && (N = Wi(T.sheet)), N)
                        }, e);
                        break;
                    case "IFRAME":
                        w = {
                                tag: d,
                                attributes: f
                            },
                            function(t) {
                                var e, n = !1;
                                if (t.nodeType === Node.ELEMENT_NODE && "IFRAME" === t.tagName) {
                                    e = t;
                                    try {
                                        e.contentDocument && (ne.set(e.contentDocument, e), ae.set(e, {
                                            doc: e.contentDocument,
                                            win: e.contentWindow
                                        }), n = !0)
                                    } catch (t) {}
                                }
                                return n
                            }(b = t) && (function(t) {
                                !1 === tr(t) && lo(t, "load", Ci.bind(this, t, "childList"), !0)
                            }(b), w.attributes["*O"] = "true", b.contentDocument && b.contentWindow && "loading" !== b.contentDocument.readyState && (_ = b.contentDocument)), 2 === e && Xi(b), i(t, r, w, e);
                        break;
                    case "LINK":
                        if (Ge && "stylesheet" === f.rel) {
                            for (k in Object.keys(document.styleSheets))
                                if ((S = document.styleSheets[k]).ownerNode == s) {
                                    i(t, r, {
                                        tag: "STYLE",
                                        attributes: f,
                                        value: Wi(S)
                                    }, e);
                                    break
                                }
                            break
                        }
                        i(t, r, {
                            tag: d,
                            attributes: f
                        }, e);
                        break;
                    case "VIDEO":
                    case "AUDIO":
                    case "SOURCE":
                        "src" in f && f.src.startsWith("data:") && (f.src = ""), i(t, r, {
                            tag: d,
                            attributes: f
                        }, e);
                        break;
                    default:
                        ! function(t) {
                            var e;
                            (null === (e = window.customElements) || void 0 === e ? void 0 : e.get) && window.customElements.get(t) && mi(t)
                        }(s.localName), E = {
                            tag: d,
                            attributes: f
                        }, s.shadowRoot && (_ = s.shadowRoot), i(t, r, E, e)
                }
        }
        return _
    }

    function ji(t) {
        tr(t) || ho(t) || (function(t) {
            var e, n;
            try {
                (n = (e = In("MutationObserver")) in window ? new window[e](co(Mi)) : null) && (n.observe(t, {
                    attributes: !0,
                    childList: !0,
                    characterData: !0,
                    subtree: !0
                }), Yt.set(t, n), xt.add(n)), t.defaultView && Ai(t.defaultView)
            } catch (t) {
                _r(2, 0, t ? t.name : null)
            }
        }(t), function(t) {
            ! function(t) {
                var e = Ji(t);
                lo(e ? e.contentWindow : t === document ? window : t, "scroll", it, !0)
            }(t), t.nodeType === Node.DOCUMENT_NODE && (function(t) {
                lo(t, "click", Ea.bind(this, 9, t), !0), lo(t, "contextmenu", Ea.bind(this, 48, t), !0)
            }(t), function(t) {
                lo(t, "cut", xa.bind(this, 0), !0), lo(t, "copy", xa.bind(this, 1), !0), lo(t, "paste", xa.bind(this, 2), !0)
            }(t), function(t) {
                lo(t, "mousedown", Ra.bind(this, 13, t), !0), lo(t, "mouseup", Ra.bind(this, 14, t), !0), lo(t, "mousemove", Ra.bind(this, 12, t), !0), lo(t, "wheel", Ra.bind(this, 15, t), !0), lo(t, "dblclick", Ra.bind(this, 16, t), !0), lo(t, "touchstart", La.bind(this, 17, t), !0), lo(t, "touchend", La.bind(this, 18, t), !0), lo(t, "touchmove", La.bind(this, 19, t), !0), lo(t, "touchcancel", La.bind(this, 20, t), !0)
            }(t), function(t) {
                lo(t, "input", Da, !0), lo(t, "keydown", Ca, !0)
            }(t), function(t) {
                lo(t, "selectstart", Ja.bind(this, t), !0), lo(t, "selectionchange", Ja.bind(this, t), !0)
            }(t), function(t) {
                lo(t, "change", wa, !0)
            }(t), function(t) {
                lo(t, "submit", Za, !0)
            }(t))
        }(t))
    }

    function Xi(t) {
        fo(t);
        var e, n, a, i = (a = t, (ae.has(a) ? ae.get(a) : null) || {}),
            r = i.doc,
            o = void 0 === r ? null : r,
            u = i.win,
            c = void 0 === u ? null : u;
        c && fo(c), o && (fo(o), e = o, (n = Yt.get(e)) && (n.disconnect(), xt.delete(n), Yt.delete(e)), function(t, e) {
            ae.delete(t), ne.delete(e)
        }(t, o))
    }

    function Wi(t) {
        var e, n = "",
            a = null;
        try {
            a = t ? t.cssRules : []
        } catch (t) {
            if (_r(1, 1, t ? t.name : null), t && "SecurityError" !== t.name) throw t
        }
        if (null !== a)
            for (e = 0; e < a.length; e++) n += a[e].cssText;
        return n
    }

    function Hi(t, e) {
        var n, a, i, r, o = t.attributes,
            u = t.prefix ? t.prefix[e] : null,
            c = 0 === e ? "~" + (t.position - 1) : ":nth-of-type(" + t.position + ")";
        switch (t.tag) {
            case "STYLE":
            case "TITLE":
            case "LINK":
            case "META":
            case "*T":
            case "*D":
                return "";
            case "HTML":
                return "HTML";
            default:
                return null === u ? "" : (u += ">", t.tag = 0 === t.tag.indexOf("svg:") ? t.tag.substr("svg:".length) : t.tag, n = u + t.tag + c, a = "id" in o && o.id.length > 0 ? o.id : null, i = "BODY" !== t.tag && "class" in o && o.class.length > 0 ? o.class.trim().split(/\s+/).filter((function(t) {
                    return qi(t)
                })).join(".") : null, i && i.length > 0 && (0 === e ? (r = function(t) {
                    var e, n, a, i;
                    for (e = t.split(">"), n = 0; n < e.length; n++) a = e[n].indexOf("~"), i = e[n].indexOf("."), e[n] = e[n].substring(0, i > 0 ? i : a > 0 ? a : e[n].length);
                    return e.join(">")
                }(u) + t.tag + "." + i, r in Ut || (Ut[r] = []), Ut[r].includes(t.id) || Ut[r].push(t.id), n = r + "~" + Ut[r].indexOf(t.id)) : n = u + t.tag + "." + i + c), n = a && qi(a) ? function(t) {
                    var e = t.lastIndexOf("*S"),
                        n = t.lastIndexOf("iframe:HTML"),
                        a = Math.max(e, n);
                    return a < 0 ? "" : t.substring(0, t.indexOf(">", a) + 1)
                }(u) + "#" + a : n, n)
        }
    }

    function qi(t) {
        var e, n;
        if (!t) return !1;
        if (qt.some((function(e) {
                return t.toLowerCase().includes(e)
            }))) return !1;
        for (e = 0; e < t.length; e++)
            if ((n = t.charCodeAt(e)) >= 48 && n <= 57) return !1;
        return !0
    }

    function Ui() {
        zt = 1, Vt = [], Bt = [], Jt = {}, Kt = [], Gt = [], Zt = A, Qt = R, $t = P, te = L, Ft = new Map, ee = new WeakMap, ne = new WeakMap, ae = new WeakMap, ie = new WeakMap, re = new WeakMap, Ut = {}
    }

    function zi(t, e) {
        void 0 === e && (e = !1);
        try {
            e && xn.unmask.forEach((function(t) {
                return t.includes("!") ? Kt.push(t.substr(1)) : Gt.push(t)
            })), "querySelectorAll" in t && (xn.regions.forEach((function(e) {
                return t.querySelectorAll(e[1]).forEach((function(t) {
                    return ir(t, "" + e[0])
                }))
            })), xn.mask.forEach((function(e) {
                return t.querySelectorAll(e).forEach((function(t) {
                    return ie.set(t, 3)
                }))
            })), xn.checksum.forEach((function(e) {
                return t.querySelectorAll(e[1]).forEach((function(t) {
                    return re.set(t, e[0])
                }))
            })), Gt.forEach((function(e) {
                return t.querySelectorAll(e).forEach((function(t) {
                    return ie.set(t, 0)
                }))
            })))
        } catch (t) {
            _r(5, 1, t ? t.name : null)
        }
    }

    function Fi(t, e) {
        if (void 0 === e && (e = !1), null === t) return null;
        var n = ee.get(t);
        return !n && e && (n = zt++, ee.set(t, n)), n || null
    }

    function Vi(t, e, n, a) {
        var i, r, o, u, c, l, s = e ? Fi(e) : null;
        (e && s || null != t.host || t.nodeType === Node.DOCUMENT_TYPE_NODE) && (i = Fi(t, !0), r = nr(t), o = null, u = rr(t) ? i : null, c = re.has(t) ? re.get(t) : null, l = xn.content ? 1 : 3, s >= 0 && Vt[s] && ((o = Vt[s]).children.push(i), u = null === u ? o.region : u, c = null === c ? o.metadata.fraud : c, l = o.metadata.privacy), n.attributes && "data-clarity-region" in n.attributes && (ir(t, n.attributes["data-clarity-region"]), u = i), Ft.set(i, t), Vt[i] = {
            id: i,
            parent: s,
            previous: r,
            children: [],
            data: n,
            selector: null,
            hash: null,
            region: u,
            metadata: {
                active: !0,
                suspend: !1,
                privacy: l,
                position: null,
                fraud: c,
                size: null
            }
        }, function(t, e, n) {
            var a, i, r, o, u, c, l, s, d = e.data,
                f = e.metadata,
                h = f.privacy,
                p = d.attributes || {},
                g = d.tag.toUpperCase();
            switch (!0) {
                case te.includes(g):
                    i = p.type, r = "", o = ["class", "style"], Object.keys(p).filter((function(t) {
                        return !o.includes(t)
                    })).forEach((function(t) {
                        return r += p[t].toLowerCase()
                    })), u = Qt.some((function(t) {
                        return r.includes(t)
                    })), f.privacy = "INPUT" === g && $t.includes(i) ? h : u ? 4 : 2;
                    break;
                case "data-clarity-mask" in p:
                    f.privacy = 3;
                    break;
                case "data-clarity-unmask" in p:
                    f.privacy = 0;
                    break;
                case ie.has(t):
                    f.privacy = ie.get(t);
                    break;
                case re.has(t):
                    f.privacy = 2;
                    break;
                case "*T" === g:
                    c = n && n.data ? n.data.tag : "", l = n && n.selector ? n.selector[1] : "", s = ["STYLE", "TITLE", "svg:style"], f.privacy = s.includes(c) || Kt.some((function(t) {
                        return l.includes(t)
                    })) ? 0 : h;
                    break;
                case 1 === h:
                    f.privacy = function(t, e, n) {
                        return t && e.some((function(e) {
                            return t.includes(e)
                        })) ? 2 : n.privacy
                    }(p.class, Zt, f);
                    break;
                case "IMG" === g:
                    (null === (a = p.src) || void 0 === a ? void 0 : a.startsWith("blob:")) && (f.privacy = 3)
            }
        }(t, Vt[i], o), Gi(Vt[i]), function(t) {
            if ("IMG" === t.data.tag && 3 === t.metadata.privacy) {
                var e = Qi(t.id);
                !e || e.complete && 0 !== e.naturalWidth || lo(e, "load", (function() {
                    e.setAttribute("data-clarity-loaded", "" + ao())
                })), t.metadata.size = []
            }
        }(Vt[i]), ar(i, a))
    }

    function Bi(t, e, n, a) {
        var i, r, o, u, c, l = Fi(t),
            s = e ? Fi(e) : null,
            d = nr(t),
            f = !1,
            h = !1;
        if (l in Vt) {
            for (c in (i = Vt[l]).metadata.active = !0, i.previous !== d && (f = !0, i.previous = d), i.parent !== s && (f = !0, r = i.parent, i.parent = s, null !== s && s >= 0 ? (o = null === d ? 0 : Vt[s].children.indexOf(d) + 1, Vt[s].children.splice(o, 0, l), i.region = rr(t) ? l : Vt[s].region) : function(t, e) {
                    if (t in Vt) {
                        var n = Vt[t];
                        n.metadata.active = !1, n.parent = null, ar(t, e), er(t)
                    }
                }(l, a), null !== r && r >= 0 && (u = Vt[r].children.indexOf(l)) >= 0 && Vt[r].children.splice(u, 1), h = !0), n) Ki(i.data, n, c) && (f = !0, i.data[c] = n[c]);
            Gi(i), ar(l, a, f, h)
        }
    }

    function Ji(t) {
        var e = t.nodeType === Node.DOCUMENT_NODE ? t : null;
        return e && ne.has(e) ? ne.get(e) : null
    }

    function Ki(t, e, n) {
        var a;
        if ("object" == typeof t[n] && "object" == typeof e[n]) {
            for (a in t[n])
                if (t[n][a] !== e[n][a]) return !0;
            for (a in e[n])
                if (e[n][a] !== t[n][a]) return !0;
            return !1
        }
        return t[n] !== e[n]
    }

    function Gi(t) {
        var e = t.parent && t.parent in Vt ? Vt[t.parent] : null,
            n = e ? e.selector : null,
            a = t.data,
            i = function(t, e) {
                var n, a;
                for (e.metadata.position = 1, n = t ? t.children.indexOf(e.id) : -1; n-- > 0;)
                    if (a = Vt[t.children[n]], e.data.tag === a.data.tag) {
                        e.metadata.position = a.metadata.position + 1;
                        break
                    }
                return e.metadata.position
            }(e, t),
            r = {
                id: t.id,
                tag: a.tag,
                prefix: n,
                position: i,
                attributes: a.attributes
            };
        t.selector = [Hi(r, 0), Hi(r, 1)], t.hash = t.selector.map((function(t) {
            return t ? An(t) : null
        })), t.hash.forEach((function(e) {
            return Jt[e] = t.id
        }))
    }

    function Zi(t) {
        var e = function(t) {
                return t in Jt ? Jt[t] : null
            }(t),
            n = Qi(e);
        return null !== n && null !== n.textContent ? n.textContent.substr(0, 25) : ""
    }

    function Qi(t) {
        return Ft.has(t) ? Ft.get(t) : null
    }

    function $i(t) {
        var e = Fi(t);
        return e in Vt ? Vt[e] : null
    }

    function tr(t) {
        return Ft.has(Fi(t))
    }

    function er(t) {
        var e, n, a, i = Ft.get(t);
        if ((null == i ? void 0 : i.nodeType) !== Node.DOCUMENT_FRAGMENT_NODE && (i && (null == i ? void 0 : i.nodeType) === Node.ELEMENT_NODE && "IFRAME" === i.tagName && Xi(i), Ft.delete(t), (e = t in Vt ? Vt[t] : null) && e.children))
            for (n = 0, a = e.children; n < a.length; n++) er(a[n])
    }

    function nr(t) {
        for (var e = null; null === e && t.previousSibling;) e = Fi(t.previousSibling), t = t.previousSibling;
        return e
    }

    function ar(t, e, n, a) {
        if (void 0 === n && (n = !0), void 0 === a && (a = !1), !xn.lean || !xn.lite) {
            var i = Bt.indexOf(t);
            i >= 0 && 1 === e && a ? (Bt.splice(i, 1), Bt.push(t)) : -1 === i && n && Bt.push(t)
        }
    }

    function ir(t, e) {
        !1 === ue.has(t) && (ue.set(t, e), (de = null === de && se ? new IntersectionObserver(ur, {
            threshold: [0, .05, .1, .2, .3, .4, .5, .6, .7, .8, .9, 1]
        }) : de) && t && t.nodeType === Node.ELEMENT_NODE && de.observe(t))
    }

    function rr(t) {
        return ue && ue.has(t)
    }

    function or() {
        var t, e, n, a, i = [];
        for (t = 0, e = le; t < e.length; t++)(a = Fi((n = e[t]).node)) ? (n.state.data.id = a, ce[a] = n.state.data, oe.push(n.state)) : i.push(n);
        le = i, oe.length > 0 && bi(7)
    }

    function ur(t) {
        var e, n, a, i, r, o, u, c, l, s, d;
        for (e = 0, n = t; e < n.length; e++) i = (a = n[e]).target, r = a.boundingClientRect, o = a.intersectionRect, u = a.rootBounds, ue.has(i) && r.width + r.height > 0 && u && u.width > 0 && u.height > 0 && (l = (c = i ? Fi(i) : null) in ce ? ce[c] : {
            id: c,
            name: ue.get(i),
            interaction: 16,
            visibility: 0
        }, d = ((s = (o ? o.width * o.height * 1 / (u.width * u.height) : 0) > .05 || a.intersectionRatio > .8) || 10 == l.visibility) && Math.abs(r.top) + u.height > r.height, cr(i, l, l.interaction, d ? 13 : s ? 10 : 0), l.visibility >= 13 && de && de.unobserve(i));
        oe.length > 0 && bi(7)
    }

    function cr(t, e, n, a) {
        var i = n > e.interaction || a > e.visibility;
        e.interaction = n > e.interaction ? n : e.interaction, e.visibility = a > e.visibility ? a : e.visibility, e.id ? (e.id in ce && i || !(e.id in ce)) && (ce[e.id] = e, oe.push(lr(e))) : le.push({
            node: t,
            state: lr(e)
        })
    }

    function lr(t) {
        return {
            time: Cn(),
            data: {
                id: t.id,
                interaction: t.interaction,
                visibility: t.visibility,
                name: t.name
            }
        }
    }

    function sr() {
        oe = []
    }

    function dr(t) {
        var e = t.composed && t.composedPath ? t.composedPath() : null,
            n = e && e.length > 0 ? e[0] : t.target;
        return Rt = Cn() + 3e3, n && n.nodeType === Node.DOCUMENT_NODE ? n.documentElement : n
    }

    function fr(t, e, n) {
        var a, i, r;
        return void 0 === n && (n = null), a = {
            id: 0,
            hash: null,
            privacy: 2,
            region: ""
        }, t && null !== (i = $i(t)) && (r = i.metadata, a.id = i.id, a.hash = i.hash, a.privacy = r.privacy, a.region = i.region ? function(t) {
            var e = Qi(t);
            return (e && ue ? ue.get(e) : "") || ""
        }(i.region) : "", i.region && function(t, e) {
            var n = Qi(t),
                a = t in ce ? ce[t] : {
                    id: t,
                    visibility: 0,
                    interaction: 16,
                    name: ue.get(n)
                },
                i = 16;
            switch (e) {
                case 9:
                    i = 20;
                    break;
                case 27:
                    i = 30
            }
            cr(n, a, i, a.visibility)
        }(i.region, e), r.fraud && ba(r.fraud, i.id, n || i.data.value)), a
    }

    function hr(t, e) {
        return void 0 === e && (e = null), $n(this, void 0, void 0, (function() {
            var n, a, i, r, o, u, c, d, f, h, p, g, v, m, y, b, w, k, S, E, T, N, M, _, O, x, I, D, C, A, P, R, L, Y, X, W;
            return ta(this, (function(U) {
                switch (n = e || Cn(), a = [n, t], t) {
                    case 13:
                    case 14:
                    case 12:
                    case 15:
                    case 16:
                    case 17:
                    case 18:
                    case 19:
                    case 20:
                        for (i = 0, r = F; i < r.length; i++) Y = r[i], (o = fr(Y.data.target, Y.event)).id > 0 && ((a = [Y.time, Y.event]).push(o.id), a.push(Y.data.x), a.push(Y.data.y), a.push(void 0 !== Y.data.id ? Y.data.id : ""), a.push(void 0 === Y.data.isPrimary ? "true" : "" + Y.data.isPrimary), wr(a), (void 0 === Y.data.isPrimary || Y.data.isPrimary) && qn(Y.event, Y.data.x, Y.data.y, Y.time));
                        Xa();
                        break;
                    case 9:
                    case 48:
                        for (u = 0, c = H; u < c.length; u++) Y = c[u], d = fr(Y.data.target, Y.event, Y.data.text), a = [Y.time, Y.event], f = d.hash ? d.hash.join(".") : "", a.push(d.id, Y.data.x, Y.data.y, Y.data.eX, Y.data.eY, Y.data.button, Y.data.reaction, Y.data.context, Pn(Y.data.text, "click", d.privacy), Rn(Y.data.link), f, Y.data.trust, Y.data.isFullText, Y.data.w, Y.data.h, Y.data.tag, Y.data.class, Y.data.id, Y.data.source), wr(a), gr(Y.time, Y.event, f, Y.data.x, Y.data.y, Y.data.reaction, Y.data.context);
                        Oa();
                        break;
                    case 38:
                        for (h = 0, p = q; h < p.length; h++) Y = p[h], a = [Y.time, Y.event], (P = fr(Y.data.target, Y.event)).id > 0 && (a.push(P.id), a.push(Y.data.action), wr(a));
                        Ia();
                        break;
                    case 11:
                        g = G, a.push(g.width, g.height), qn(t, g.width, g.height), Ua(), wr(a);
                        break;
                    case 26:
                        v = lt, a.push(v.name, v.persisted), ti(), wr(a);
                        break;
                    case 27:
                        for (m = 0, y = z; m < y.length; m++) Y = y[m], b = fr(Y.data.target, Y.event, Y.data.value), (a = [Y.time, Y.event]).push(b.id), a.push(Pn(Y.data.value, "input", b.privacy, !1, Y.data.type)), a.push(Y.data.trust), wr(a);
                        Pa();
                        break;
                    case 21:
                        (w = rt) && (k = fr(w.start, t), S = fr(w.end, t), a.push(k.id, w.startOffset, S.id, w.endOffset), Ga(), wr(a));
                        break;
                    case 10:
                        for (E = 0, T = tt; E < T.length; E++) Y = T[E], N = fr(Y.data.target, Y.event), M = fr(Y.data.top, Y.event), _ = fr(Y.data.bottom, Y.event), O = (null == M ? void 0 : M.hash) ? M.hash.join(".") : "", x = (null == _ ? void 0 : _.hash) ? _.hash.join(".") : "", N.id > 0 && ((a = [Y.time, Y.event]).push(N.id, Y.data.x, Y.data.y, O, x, Y.data.trust), wr(a), qn(Y.event, Y.data.x, Y.data.y, Y.time));
                        tt = [], et = null, nt = null;
                        break;
                    case 42:
                        for (I = 0, D = j; I < D.length; I++) Y = D[I], a = [Y.time, Y.event], (P = fr(Y.data.target, Y.event)).id > 0 && ((a = [Y.time, Y.event]).push(P.id), a.push(Y.data.type), a.push(Pn(Y.data.value, "change", P.privacy)), a.push(Pn(Y.data.checksum, "checksum", P.privacy)), wr(a));
                        ka();
                        break;
                    case 39:
                        for (C = 0, A = ct; C < A.length; C++) Y = A[C], a = [Y.time, Y.event], (P = fr(Y.data.target, Y.event)).id > 0 && (a.push(P.id), wr(a));
                        Qa();
                        break;
                    case 22:
                        for (R = 0, L = he; R < L.length; R++) Y = L[R], (a = [Y.time, Y.event]).push(Y.data.type, Y.data.hash, Y.data.x, Y.data.y, Y.data.reaction, Y.data.context), wr(a, !1);
                        pr();
                        break;
                    case 28:
                        X = st, a.push(X.visible), wr(a),
                            function(t, e) {
                                l.visible = e, l.visible || zn(t), s = !0
                            }(n, X.visible), ni();
                        break;
                    case 50:
                        W = dt, a.push(W.focused), wr(a, !1), ai()
                }
                return [2]
            }))
        }))
    }

    function pr() {
        he = []
    }

    function gr(t, e, n, a, i, r, o) {
        void 0 === r && (r = 1), void 0 === o && (o = 0), fe.push({
            time: t,
            event: 22,
            data: {
                type: e,
                hash: n,
                x: a,
                y: i,
                reaction: r,
                context: o
            }
        }), qn(e, a, i, t)
    }

    function vr(t, e, n, a) {
        return "href" === t && "LINK" === a ? t + "=" + e : t + "=" + Pn(e, 0 === t.indexOf("data-") ? "data-" : t, n)
    }

    function mr(t) {
        var e, n = {},
            a = t.attributes;
        if (a && a.length > 0)
            for (e = 0; e < a.length; e++) n[a[e].name] = a[e].value;
        return n
    }

    function yr(t, e, n) {
        var a, i, r, o;
        t && n && n.tag && (a = function(t) {
            return null === t ? null : ve.has(t) ? ve.get(t) : (ve.set(t, ge), ge++)
        }(t), i = e ? ve.get(e) : null, r = t.previousSibling ? ve.get(t.previousSibling) : null, o = {
            active: !0,
            suspend: !1,
            privacy: 5,
            position: null,
            fraud: null,
            size: null
        }, pe.push({
            id: a,
            parent: i,
            previous: r,
            children: [],
            data: n,
            selector: null,
            hash: null,
            region: null,
            metadata: o
        }))
    }

    function br(t) {
        var e, n;
        ye && ((n = (e = t ? t.split(" ") : [""]).length > 1 ? parseInt(e[1], 10) : null) && be.has(n) || function(t, e) {
            try {
                var n = document.createElement("script");
                n.src = t, n.async = !0, n.onload = function() {
                    e && (be.add(e), function(t) {
                        l.modules = Array.from(t), s = !0
                    }(be))
                }, n.onerror = function() {
                    uo(new Error("MODULE: " + t))
                }, document.head.appendChild(n)
            } catch (t) {}
        }(e[0], n))
    }

    function wr(t, e) {
        var n, a, i, r;
        if (void 0 === e && (e = !0), Me) {
            switch (n = Cn(), a = t.length > 1 ? t[1] : null, i = JSON.stringify(t), xn.lean ? !Oe && ke + i.length > 10485760 && (_r(10, 0), Oe = !0) : Oe = !1, a) {
                case 5:
                    if (Oe) break;
                    we += i.length;
                case 37:
                case 6:
                case 43:
                case 45:
                case 46:
                case 44:
                case 51:
                    if (Oe) break;
                    ke += i.length, Se.push(i);
                    break;
                default:
                    Ee.push(i)
            }
            Bn(25), r = function() {
                var t = !1 === xn.lean && we > 0 ? 100 : tn.sequence * xn.delay;
                return "string" == typeof xn.upload ? Math.max(Math.min(t, 3e4), 100) : xn.delay
            }(), n - _e > 2 * r && (Zn(Te), Te = null), e && null === Te && (25 !== a && (m && Zn(m), m = Gn(Qn, v), g = Cn()), Te = Gn(kr, r), _e = n, function(t) {
                if (0 === qe.check) {
                    var e = qe.check;
                    e = tn.sequence >= 128 ? 1 : e, e = tn.pageNum >= 128 ? 7 : e, e = Cn() > 72e5 ? 2 : e, (e = t > 10485760 ? 2 : e) !== qe.check && Hr(e)
                }
            }(ke))
        }
    }

    function kr(t) {
        return void 0 === t && (t = !1), $n(this, void 0, void 0, (function() {
            var e, n, a, i, r, o, u, c, l, d;
            return ta(this, (function(f) {
                switch (f.label) {
                    case 0:
                        return Me ? (Te = null, (e = !1 === xn.lean && ke > 0 && (ke < 1048576 || tn.sequence > 0)) && Kn(1, 1), or(), function() {
                            var t, e, n, a, i, r;
                            if (tn) {
                                for (t = [], he = [], e = (tn.start || 0) + (tn.duration || 0), n = Math.max(e - 2e3, 0), a = 0, i = fe; a < i.length; a++)(r = i[a]).time >= n && (r.time <= e && he.push(r), t.push(r));
                                fe = t, hr(22)
                            }
                        }(), function() {
                            var t, e;
                            Wr(34), s && Wr(4), Wr(1), Wr(0), Wr(36), 0 !== qe.check && Wr(35),
                                function() {
                                    var t, e, n, a, i, r, o, u, c, l, s, d, f, h, p, g, v;
                                    try {
                                        for (t in E)
                                            if (e = parseInt(t), "" == M[e] || document.querySelector(M[e])) {
                                                for (a in n = E[e])(r = (v = fa(ca(n[i = parseInt(a)]))) ? JSON.stringify(v).slice(0, 1e4) : v) && sa(e, i, r);
                                                for (u in o = T[e]) c = !1, (s = o[l = parseInt(u)]).startsWith("@") && (c = !0, s = s.slice(1)), (d = document.querySelectorAll(s)) && (f = Array.from(d).map((function(t) {
                                                    if ("IMG" === t.tagName) {
                                                        var e = t;
                                                        return e.src || e.currentSrc || ""
                                                    }
                                                    return t.textContent
                                                })).join("<SEP>"), sa(e, l, (c ? An(f).trim() : f).slice(0, 1e4)));
                                                for (p in h = N[e]) sa(e, g = parseInt(p), Zi(h[g]).trim().slice(0, 1e4))
                                            }
                                        S.size > 0 && Wr(40)
                                    } catch (t) {
                                        _r(5, 1, t ? t.name : null)
                                    }
                                }(), Be && (Wr(47), Be = !1, xn.track || (null == (e = null === (t = window.google_tag_data) || void 0 === t ? void 0 : t.ics) ? void 0 : e.usedUpdate) && Ur())
                        }(), function() {
                            var t, e, n, a;
                            for (t = 0, e = yt; t < e.length; t++) si(n = e[t], (a = n == document ? -1 : Fi(n)) in mt ? mt[a] : null)
                        }(), n = !0 === t, tn ? (a = JSON.stringify(function(t) {
                            return tn.start = tn.start + tn.duration, tn.duration = Cn() - tn.start, tn.sequence++, tn.upload = t && "sendBeacon" in navigator ? 1 : 0, tn.end = t ? 1 : 0, tn.applicationPlatform = 0, tn.url = Rn(location.href, !1, !0), [tn.version, tn.sequence, tn.start, tn.duration, tn.projectId, tn.userId, tn.sessionId, tn.pageNum, tn.upload, tn.end, tn.applicationPlatform, tn.url]
                        }(n)), i = Ee, Ee = [], e && (r = Se, Se = [], ke = 0, we = 0, Oe = !1), o = "[" + i.join() + "]", u = e ? "[" + r.join() + "]" : "", n && u.length > 0 && a.length + o.length + u.length > 65536 && (u = ""), c = (h = {
                            e: a,
                            a: o,
                            p: u
                        }).p.length > 0 ? '{"e":' + h.e + ',"a":' + h.a + ',"p":' + h.p + "}" : '{"e":' + h.e + ',"a":' + h.a + "}", n ? (d = null, [3, 3]) : [3, 1]) : [2]) : [2];
                    case 1:
                        return [4, ea(c)];
                    case 2:
                        d = f.sent(), f.label = 3;
                    case 3:
                        return Jn(2, (l = d) ? l.length : c.length), Sr(c, l, tn.sequence, n), [2]
                }
                var h
            }))
        }))
    }

    function Sr(t, e, n, a) {
        var i, r, o;
        if (void 0 === a && (a = !1), "string" == typeof xn.upload) {
            if (i = xn.upload, r = !1, a && navigator && navigator.sendBeacon) try {
                (r = navigator.sendBeacon.bind(navigator)(i, t)) && Tr(n)
            } catch (t) {}!1 === r && (n in Ne ? Ne[n].attempts++ : Ne[n] = {
                data: t,
                attempts: 1
            }, (o = new XMLHttpRequest).open("POST", i, !0), o.timeout = 15e3, o.ontimeout = function() {
                uo(new Error("Timeout : " + i))
            }, null !== n && (o.onreadystatechange = function() {
                co(Er)(o, n)
            }), o.withCredentials = !0, e ? (o.setRequestHeader("Accept", "application/x-clarity-gzip"), o.send(e)) : o.send(t))
        } else xn.upload && ((0, xn.upload)(t), Tr(n))
    }

    function Er(t, e) {
        var n = Ne[e];
        t && 4 === t.readyState && n && ((t.status < 200 || t.status > 208) && n.attempts <= 1 ? t.status >= 400 && t.status < 500 ? Hr(6) : (0 === t.status && (xn.upload = xn.fallback ? xn.fallback : xn.upload), xe = {
            sequence: e,
            attempts: n.attempts,
            status: t.status
        }, Wr(2), Sr(n.data, null, e)) : (xe = {
            sequence: e,
            attempts: n.attempts,
            status: t.status
        }, n.attempts > 1 && Wr(2), 200 === t.status && t.responseText && function(t) {
            var e, n, a, i;
            for (e = 0, n = t && t.length > 0 ? t.split("\n") : []; e < n.length; e++) switch ((i = (a = n[e]) && a.length > 0 ? a.split(/ (.*)/) : [""])[0]) {
                case "END":
                    Hr(6);
                    break;
                case "UPGRADE":
                    Xr("Auto");
                    break;
                case "ACTION":
                    xn.action && i.length > 1 && xn.action(i[1]);
                    break;
                case "EXTRACT":
                    i.length > 1 && ua(i[1]);
                    break;
                case "SIGNAL":
                    i.length > 1 && ya(i[1]);
                    break;
                case "MODULE":
                    i.length > 1 && br(i[1]);
                    break;
                case "SNAPSHOT":
                    xn.lean = !1, pe = [],
                        function(t) {
                            for (var e, n, a, i, r, o, u, c, l = [document]; l.length > 0;) {
                                for (e = null, n = null, a = null, r = (i = l.shift()).firstChild, o = i.parentElement ? i.parentElement : i.parentNode ? i.parentNode : null; r;) l.push(r), r = r.nextSibling;
                                switch (i.nodeType) {
                                    case Node.DOCUMENT_TYPE_NODE:
                                        n = "*D", e = {
                                            name: (u = i).name,
                                            publicId: u.publicId,
                                            systemId: u.systemId
                                        };
                                        break;
                                    case Node.TEXT_NODE:
                                        a = i.nodeValue, n = ve.get(o) ? "*T" : n;
                                        break;
                                    case Node.ELEMENT_NODE:
                                        e = mr(c = i), n = ["NOSCRIPT", "SCRIPT", "STYLE"].includes(c.tagName) ? n : c.tagName
                                }
                                yr(i, o, {
                                    tag: n,
                                    attributes: e,
                                    value: a
                                })
                            }
                        }(),
                        function(t) {
                            $n(this, void 0, void 0, (function() {
                                var t, e, n, a, i, r, o, u, c, l, s, d;
                                return ta(this, (function(f) {
                                    if (t = Cn(), e = [t, 43], (n = pe).length > 0) {
                                        for (a = 0, i = n; a < i.length; a++)
                                            for (r = i[a], o = r.metadata.privacy, u = r.data, c = 0, l = ["tag", "attributes", "value"]; c < l.length; c++)
                                                if (u[s = l[c]]) switch (s) {
                                                    case "tag":
                                                        e.push(r.id), r.parent && e.push(r.parent), r.previous && e.push(r.previous), e.push(u[s]);
                                                        break;
                                                    case "attributes":
                                                        for (d in u[s]) void 0 !== u[s][d] && e.push(vr(d, u[s][d], o, u.tag));
                                                        break;
                                                    case "value":
                                                        e.push(Pn(u[s], u.tag, o))
                                                }
                                        wr(oi(e), !0)
                                    }
                                    return [2]
                                }))
                            }))
                        }()
            }
        }(t.responseText), 0 === t.status && (Sr(n.data, null, e, !0), Hr(3)), t.status >= 200 && t.status <= 208 && Tr(e), delete Ne[e]))
    }

    function Tr(t) {
        1 === t && (eo(), to())
    }

    function Nr(t) {
        var e = t.error || t;
        return e.message in Ie || (Ie[e.message] = 0), Ie[e.message]++ >= 5 || e && e.message && (De = {
            message: e.message,
            line: t.lineno,
            column: t.colno,
            stack: e.stack,
            source: t.filename
        }, Mr(31)), !0
    }

    function Mr(t) {
        return $n(this, void 0, void 0, (function() {
            var e;
            return ta(this, (function(n) {
                switch (e = [Cn(), t], t) {
                    case 31:
                        e.push(De.message, De.line, De.column, De.stack, Rn(De.source)), wr(e);
                        break;
                    case 33:
                        Ae && (e.push(Ae.code, Ae.name, Ae.message, Ae.stack, Ae.severity), wr(e, !1));
                        break;
                    case 41:
                        C && (e.push(C.id, C.target, C.checksum), wr(e, !1))
                }
                return [2]
            }))
        }))
    }

    function _r(t, e, n, a, i) {
        void 0 === n && (n = null), void 0 === a && (a = null), void 0 === i && (i = null);
        var r = n ? n + "|" + a : "";
        t in Ce && Ce[t].includes(r) || (Ae = {
            code: t,
            name: n,
            message: a,
            stack: i,
            severity: e
        }, t in Ce ? Ce[t].push(r) : Ce[t] = [r], Mr(33))
    }

    function Or() {
        Re = {}, Le = [], Ye = null, je = null
    }

    function xr(t, e) {
        return void 0 === e && (e = 0), $n(this, void 0, void 0, (function() {
            var n, a, i;
            return ta(this, (function(r) {
                for (n = 0, a = Le; n < a.length; n++)
                    if (a[n].task === t) return [2];
                return i = new Promise((function(n) {
                    Le[1 === e ? "unshift" : "push"]({
                        task: t,
                        resolve: n,
                        id: Jr()
                    })
                })), null === Ye && null === je && Ir(), [2, i]
            }))
        }))
    }

    function Ir() {
        var t = Le.shift();
        t && (Ye = t, t.task().then((function() {
            t.id !== Jr() || t.resolve(), Ye = null, Ir()
        })).catch((function(e) {
            !(t.id !== Jr()) && e && _r(0, 1, e.name, e.message, e.stack), Ye = null, Ir()
        })))
    }

    function Dr(t) {
        var e = Rr(t);
        return e in Re ? performance.now() - Re[e].start > Re[e].yield ? 0 : 1 : 2
    }

    function Cr(t) {
        Re[Rr(t)] = {
            start: performance.now(),
            calls: 0,
            yield: 30
        }
    }

    function Ar(t) {
        var e = performance.now(),
            n = Rr(t),
            a = e - Re[n].start;
        Jn(t.cost, a), Bn(5), Re[n].calls > 0 && Jn(4, a)
    }

    function Pr(t) {
        var e;
        return $n(this, void 0, void 0, (function() {
            var n, a;
            return ta(this, (function(i) {
                switch (i.label) {
                    case 0:
                        return (n = Rr(t)) in Re ? (Ar(t), a = Re[n], [4, Lr()]) : [3, 2];
                    case 1:
                        a.yield = (null === (e = i.sent()) || void 0 === e ? void 0 : e.timeRemaining()) || 30,
                            function(t) {
                                var e, n, a = Rr(t);
                                Re && Re[a] && (e = Re[a].calls, n = Re[a].yield, Cr(t), Re[a].calls = e + 1, Re[a].yield = n)
                            }(t), i.label = 2;
                    case 2:
                        return [2, n in Re ? 1 : 2]
                }
            }))
        }))
    }

    function Rr(t) {
        return t.id + "." + t.cost
    }

    function Lr() {
        return $n(this, void 0, void 0, (function() {
            return ta(this, (function(t) {
                switch (t.label) {
                    case 0:
                        return je ? [4, je] : [3, 2];
                    case 1:
                        t.sent(), t.label = 2;
                    case 2:
                        return [2, new Promise((function(t) {
                            We(t, {
                                timeout: Pe
                            })
                        }))]
                }
            }))
        }))
    }

    function Yr() {
        xr(jr, 1).then((function() {
            co(Ei)(), co(or)(), co(Ba)()
        }))
    }

    function jr() {
        return $n(this, void 0, void 0, (function() {
            var t, e;
            return ta(this, (function(n) {
                switch (n.label) {
                    case 0:
                        return t = Cn(), Cr(e = {
                            id: Jr(),
                            cost: 3
                        }), [4, Ti(document, e, 0, t)];
                    case 1:
                        return n.sent(), si(document, t), [4, bi(5, e, t)];
                    case 2:
                        return n.sent(), Ar(e), [2]
                }
            }))
        }))
    }

    function Xr(t) {
        bo() && xn.lean && (xn.lean = !1, He = {
            key: t
        }, to(), eo(), xn.upgrade && xn.upgrade(t), Wr(3), xn.lite && (Yr(), li()))
    }

    function Wr(t) {
        var e, n, a, i, r, o, u, l, s, f, g, v, m, b, E, T, N, M, _ = [Cn(), t];
        switch (t) {
            case 4:
                (e = c) && e.data && (n = e.data, (_ = [e.time, e.event]).push(n.visible, n.docWidth, n.docHeight, n.screenWidth, n.screenHeight, n.scrollX, n.scrollY, n.pointerX, n.pointerY, n.activityTime, n.scrollTime, n.pointerTime, n.moveX, n.moveY, n.moveTime, n.downX, n.downY, n.downTime, n.upX, n.upY, n.upTime, n.pointerPrevX, n.pointerPrevY, n.pointerPrevTime, n.modules), wr(_, !1)), Hn();
                break;
            case 25:
                _.push(p.gap), wr(_);
                break;
            case 35:
                _.push(qe.check), wr(_, !1);
                break;
            case 3:
                _.push(He.key), wr(_);
                break;
            case 2:
                _.push(xe.sequence, xe.attempts, xe.status), wr(_, !1);
                break;
            case 24:
                d.key && _.push(d.key), _.push(d.value), wr(_);
                break;
            case 34:
                if ((a = Object.keys(w)).length > 0) {
                    for (i = 0, r = a; i < r.length; i++) o = r[i], _.push(o), _.push(w[o]);
                    ia(), wr(_, !1)
                }
                break;
            case 0:
                if ((u = Object.keys(h)).length > 0) {
                    for (l = 0, s = u; l < s.length; l++) f = s[l], g = parseInt(f, 10), _.push(g), _.push(Math.round(h[f]));
                    h = {}, wr(_, !1)
                }
                break;
            case 1:
                if ((v = Object.keys(ze)).length > 0) {
                    for (m = 0, b = v; m < b.length; m++) n = b[m], g = parseInt(n, 10), _.push(g), _.push(ze[n]);
                    ze = {}, Fe = !1, wr(_, !1)
                }
                break;
            case 36:
                if ((E = Object.keys(y)).length > 0) {
                    for (T = 0, N = E; T < N.length; T++) M = N[T], g = parseInt(M, 10), _.push(g), _.push([].concat.apply([], y[M]));
                    y = {}, wr(_, !1)
                }
                break;
            case 40:
                S.forEach((function(t) {
                    var e, n, a;
                    for (n in _.push(t), e = [], k[t]) a = parseInt(n, 10), e.push(a), e.push(k[t][n]);
                    _.push(e)
                })), la(), wr(_, !1);
                break;
            case 47:
                _.push(Ve.source, Ve.ad_Storage, Ve.analytics_Storage), wr(_, !1)
        }
    }

    function Hr(t) {
        qe.check = t, 5 !== t && (Qr(), _o())
    }

    function qr(t, e) {
        if (e && (e = "" + e, t in Ue || (Ue[t] = []), !Ue[t].includes(e))) {
            if (Ue[t].length > 128) return void(Fe || (Fe = !0, Hr(5)));
            Ue[t].push(e), t in ze || (ze[t] = []), ze[t].push(e)
        }
    }

    function Ur() {
        var t, e, n, a = null === (t = window.google_tag_data) || void 0 === t ? void 0 : t.ics;
        if (null == a ? void 0 : a.getConsentState) try {
            e = a.getConsentState("analytics_storage"), Kr({
                source: 2,
                ad_Storage: 1 === (n = {
                    ad_Storage: a.getConsentState("ad_storage"),
                    analytics_Storage: e
                }).ad_Storage ? "granted" : "denied",
                analytics_Storage: 1 === n.analytics_Storage ? "granted" : "denied"
            })
        } catch (t) {
            return
        }
    }

    function zr() {
        Fr(2)
    }

    function Fr(t) {
        qr(36, "" + t)
    }

    function Vr(t) {
        Ve = t, Wr(47)
    }

    function Br() {
        var t, e, n, a;
        if (!Qe && "granted" === (null == Ze ? void 0 : Ze.analytics_Storage) && "granted" === (null == Ze ? void 0 : Ze.ad_Storage)) {
            for (t = 0, e = xn.cookies; t < e.length; t++)(a = va(n = e[t])) && na(n, a);
            Qe = !0
        }
    }

    function Jr() {
        return Je ? [Je.userId, Je.sessionId, Je.pageNum].join(".") : ""
    }

    function Kr(t, e) {
        var n, a, i;
        if (void 0 === t && (t = $e), void 0 === e && (e = 5), bo()) {
            if (a = {
                    source: null !== (n = t.source) && void 0 !== n ? n : e,
                    ad_Storage: Zr(t.ad_Storage, null == Ze ? void 0 : Ze.ad_Storage),
                    analytics_Storage: Zr(t.analytics_Storage, null == Ze ? void 0 : Ze.analytics_Storage)
                }, Ze && a.ad_Storage === Ze.ad_Storage && a.analytics_Storage === Ze.analytics_Storage) return Ze.source = a.source, Vr(Gr(Ze)), void zr();
            if (Ze = a, to(!0), !(i = Gr(Ze)).analytics_Storage && xn.track) return xn.track = !1, Qr(!0), _o(), void window.setTimeout(Mo, 250);
            bo() && i.analytics_Storage && (xn.track = !0, no(ro(), 1), qr(15, $r()), eo()), Br(), Vr(i), zr()
        }
    }

    function Gr(t) {
        var e;
        return {
            source: null !== (e = t.source) && void 0 !== e ? e : 255,
            ad_Storage: "granted" === t.ad_Storage ? 1 : 0,
            analytics_Storage: "granted" === t.analytics_Storage ? 1 : 0
        }
    }

    function Zr(t, e) {
        return void 0 === e && (e = "denied"), "string" == typeof t ? t.toLowerCase() : e
    }

    function Qr(t) {
        void 0 === t && (t = !1), ma("_clsk", "", 0), t && ma("_clck", "", 0)
    }

    function $r() {
        var t = ao();
        return xn.track && pa(window, "sessionStorage") && (t = sessionStorage.getItem("_cltk") || t, sessionStorage.setItem("_cltk", t)), t
    }

    function to(t) {
        void 0 === t && (t = !1),
            function(t, e) {
                var n, a;
                if (void 0 === e && (e = !1), Ke.length > 0)
                    for (n = 0; n < Ke.length; n++)(a = Ke[n]).callback && (!a.called && !e || a.consentInfo && e) && (!a.wait || t) && (a.callback(Je, !xn.lean, a.consentInfo ? Ze : void 0), a.called = !0, a.recall || (Ke.splice(n, 1), n--))
            }(xn.lean ? 0 : 1, t)
    }

    function eo() {
        var t, e, n;
        Je && xn.track && (t = Math.round(Date.now()), e = xn.upload && "string" == typeof xn.upload ? xn.upload.replace("https://", "") : "", n = xn.lean ? 0 : 1, ma("_clsk", [Je.sessionId, t, Je.pageNum, n, e].join(O), 1))
    }

    function no(t, e) {
        var n, a;
        void 0 === e && (e = null), e = null === e ? t.consent : e, n = Math.ceil((Date.now() + 31536e6) / 864e5), a = 0 === t.dob ? null === xn.dob ? 0 : xn.dob : t.dob, (null === t.expiry || Math.abs(n - t.expiry) >= 1 || t.consent !== e || t.dob !== a) && ma("_clck", [Je.userId, 2, n.toString(36), e, a].join(O), 365)
    }

    function ao() {
        var t = Math.floor(Math.random() * Math.pow(2, 32));
        return window && window.crypto && window.crypto.getRandomValues && Uint32Array && (t = window.crypto.getRandomValues(new Uint32Array(1))[0]), t.toString(36)
    }

    function io(t, e) {
        return void 0 === e && (e = 10), parseInt(t, e)
    }

    function ro() {
        var t, e = {
                id: ao(),
                version: 0,
                expiry: null,
                consent: 0,
                dob: 0
            },
            n = va("_clck", !xn.includeSubdomains);
        return n && n.length > 0 && ((t = n.includes("^") ? n.split("^") : n.split("|")).length > 1 && (e.version = io(t[1])), t.length > 2 && (e.expiry = io(t[2], 36)), t.length > 3 && 1 === io(t[3]) && (e.consent = 1), t.length > 4 && io(t[1]) > 1 && (e.dob = io(t[4])), xn.track = xn.track || 1 === e.consent, e.id = xn.track ? t[0] : e.id), e
    }

    function oo() {
        en = []
    }

    function uo(t) {
        var e, n, a;
        return en && !en.includes(t.message) && (e = xn.report) && e.length > 0 && tn && (n = {
            v: tn.version,
            p: tn.projectId,
            u: tn.userId,
            s: tn.sessionId,
            n: tn.pageNum
        }, t.message && (n.m = t.message), t.stack && (n.e = t.stack), (a = new XMLHttpRequest).open("POST", e, !0), a.send(JSON.stringify(n)), en.push(t.message)), t
    }

    function co(t) {
        return function() {
            var e, n = performance.now();
            try {
                t.apply(this, arguments)
            } catch (t) {
                throw uo(t)
            }
            Jn(4, e = performance.now() - n), e > 30 && (Bn(7), Kn(6, e), t.dn && _r(9, 0, t.dn + "-" + e))
        }
    }

    function lo(t, e, n, a, i) {
        void 0 === a && (a = !1), void 0 === i && (i = !0), n = co(n);
        try {
            t[In("addEventListener")](e, n, {
                capture: a,
                passive: i
            }), ho(t) || nn.set(t, []), nn.get(t).push({
                event: e,
                listener: n,
                options: {
                    capture: a,
                    passive: i
                }
            })
        } catch (t) {}
    }

    function so() {
        nn.forEach((function(t, e) {
            po(t, e)
        })), nn = new Map
    }

    function fo(t) {
        ho(t) && po(nn.get(t), t)
    }

    function ho(t) {
        return nn.has(t)
    }

    function po(t, e) {
        t.forEach((function(t) {
            try {
                e[In("removeEventListener")](t.event, t.listener, {
                    capture: t.options.capture,
                    passive: t.options.passive
                })
            } catch (t) {}
        })), nn.delete(e)
    }

    function go(t, e) {
        if (null === t) try {
            t = history[e], history[e] = function() {
                if (un >= 20) _r(4, 0);
                else {
                    un++;
                    try {
                        t.apply(this, arguments)
                    } finally {
                        un--
                    }
                    bo() && vo()
                }
            }
        } catch (e) {
            t = null
        }
        return t
    }

    function vo() {
        var t;
        on !== yo() && (_o(), window.setTimeout(mo, null !== (t = xn.restart) && void 0 !== t ? t : 250))
    }

    function mo() {
        Mo(), Kn(29, 1)
    }

    function yo() {
        return location.href ? location.href.replace(location.hash, "") : location.href
    }

    function bo() {
        return cn
    }

    function wo() {
        Mo(), Fn("clarity", "restart")
    }

    function ko() {
        ln = null
    }

    function So(t) {
        ln = {
                fetchStart: Math.round(t.fetchStart),
                connectStart: Math.round(t.connectStart),
                connectEnd: Math.round(t.connectEnd),
                requestStart: Math.round(t.requestStart),
                responseStart: Math.round(t.responseStart),
                responseEnd: Math.round(t.responseEnd),
                domInteractive: Math.round(t.domInteractive),
                domComplete: Math.round(t.domComplete),
                loadEventStart: Math.round(t.loadEventStart),
                loadEventEnd: Math.round(t.loadEventEnd),
                redirectCount: Math.round(t.redirectCount),
                size: t.transferSize ? t.transferSize : 0,
                type: t.type,
                protocol: t.nextHopProtocol,
                encodedSize: t.encodedBodySize ? t.encodedBodySize : 0,
                decodedSize: t.decodedBodySize ? t.decodedBodySize : 0
            },
            function(t) {
                $n(this, void 0, void 0, (function() {
                    var t, e;
                    return ta(this, (function(n) {
                        return t = Cn(), (e = [t, 29]).push(ln.fetchStart, ln.connectStart, ln.connectEnd, ln.requestStart, ln.responseStart, ln.responseEnd, ln.domInteractive, ln.domComplete, ln.loadEventStart, ln.loadEventEnd, ln.redirectCount, ln.size, ln.type, ln.protocol, ln.encodedSize, ln.decodedSize), ko(), wr(e), [2]
                    }))
                }))
            }()
    }

    function Eo() {
        var t, e, n;
        try {
            for (Sn && Sn.disconnect(), Sn = new PerformanceObserver(co(To)), t = 0, e = En; t < e.length; t++) n = e[t], PerformanceObserver.supportedEntryTypes.includes(n) && ("layout-shift" === n && Jn(9, 0), Sn.observe({
                type: n,
                buffered: !0
            }))
        } catch (t) {
            _r(3, 1)
        }
    }

    function To(t) {
        ! function(t) {
            var e, n, a, i;
            for ((e = !("visibilityState" in document) || "visible" === document.visibilityState, n = 0); n < t.length; n++) switch ((a = t[n]).entryType) {
                case "navigation":
                    So(a);
                    break;
                case "resource":
                    qr(4, No(i = a.name)), i !== xn.upload && i !== xn.fallback || Kn(28, a.duration);
                    break;
                case "longtask":
                    Bn(7);
                    break;
                case "first-input":
                    e && Kn(10, a.processingStart - a.startTime);
                    break;
                case "event":
                    e && "PerformanceEventTiming" in window && "interactionId" in PerformanceEventTiming.prototype && (kn(a), qr(37, "" + bn()));
                    break;
                case "layout-shift":
                    e && !a.hadRecentInput && Jn(9, 1e3 * a.value);
                    break;
                case "largest-contentful-paint":
                    e && Kn(8, a.startTime)
            }
        }(t.getEntries())
    }

    function No(t) {
        return Tn || (Tn = document.createElement("a")), Tn.href = t, Tn.host
    }

    function Mo(e) {
        void 0 === e && (e = null),
            function(t) {
                void 0 === t && (t = null);
                try {
                    var e = navigator && "globalPrivacyControl" in navigator && 1 == navigator.globalPrivacyControl;
                    return !1 === cn && "undefined" != typeof Promise && window.MutationObserver && document.createTreeWalker && "now" in Date && "now" in performance && "undefined" != typeof WeakMap && (!e || t && t.diagnostics)
                } catch (t) {
                    return !1
                }
            }(e) && (function(t) {
                if (null === t || cn) return !1;
                for (var e in t) e in xn && (xn[e] = t[e])
            }(e), cn = !0, t = Dn(), Or(), so(), oo(), on = yo(), un = 0, lo(window, "popstate", vo), an = go(an, "pushState"), rn = go(rn, "replaceState"), f = {}, h = {}, Bn(5), I.forEach((function(t) {
                return co(t.start)()
            })), Nn.forEach((function(t) {
                return co(t.start)()
            })), null === e && Oo())
    }

    function _o() {
        bo() && (Nn.slice().reverse().forEach((function(t) {
            return co(t.stop)()
        })), I.slice().reverse().forEach((function(t) {
            return co(t.stop)()
        })), f = {}, h = {}, on = null, un = 0, oo(), so(), Or(), t = 0, cn = !1, void 0 !== _n && (_n[On] = function() {
            (_n[On].q = _n[On].q || []).push(arguments), "start" === arguments[0] && _n[On].q.unshift(_n[On].q.pop()) && Oo()
        }))
    }

    function Oo() {
        if (void 0 !== _n) {
            if (_n[On] && _n[On].v) return console.warn("Error CL001: Multiple Clarity tags detected.");
            var t = _n[On] && _n[On].q || [];
            for (_n[On] = function(t) {
                    var e, n = [];
                    for (e = 1; e < arguments.length; e++) n[e - 1] = arguments[e];
                    return Mn[t].apply(Mn, n)
                }, _n[On].v = e; t.length > 0;) _n[On].apply(_n, t.shift())
        }
    }
    t = 0, e = "0.8.69", n = /\S/gi, a = 2048, i = !0, r = null, o = null, u = null, c = null, l = null, s = !1, d = null, f = null, h = null, g = 0, v = 0, m = null, y = null, b = "CompressionStream" in window, w = null, k = {}, S = new Set, E = {}, T = {}, N = {}, M = {}, _ = null, O = "^", x = null, I = [{
        start: function() {
            s = !1, Hn()
        },
        stop: function() {
            Hn()
        }
    }, {
        start: function() {
            Ue = {}, ze = {}, Fe = !1
        },
        stop: function() {
            Ue = {}, ze = {}, Fe = !1
        }
    }, {
        start: function() {
            ia()
        },
        stop: function() {
            ia()
        }
    }, {
        start: function() {
            qe = {
                check: 0
            }
        },
        stop: function() {
            qe = null
        }
    }, {
        start: function() {
            y = {}
        },
        stop: function() {
            y = {}
        }
    }, {
        start: function() {
            _ = null
        },
        stop: function() {
            _ = null
        }
    }, {
        start: function() {
            var t, e = null === (t = window.google_tag_data) || void 0 === t ? void 0 : t.ics;
            Be = !0, (null == e ? void 0 : e.addListener) && e.addListener(["ad_storage", "analytics_storage"], Ur)
        },
        stop: function() {
            Be = !0
        }
    }, {
        start: function() {
            var t, e, n, a, i, r, o, u, c, l, s, d, f = navigator && "userAgent" in navigator ? navigator.userAgent : "",
                h = null !== (n = "undefined" != typeof Intl && (null === (e = null === (t = null === Intl || void 0 === Intl ? void 0 : Intl.DateTimeFormat()) || void 0 === t ? void 0 : t.resolvedOptions()) || void 0 === e ? void 0 : e.timeZone)) && void 0 !== n ? n : "",
                p = "" + (new Date).getTimezoneOffset(),
                g = window.location.ancestorOrigins ? Array.from(window.location.ancestorOrigins).toString() : "",
                v = document && document.title ? document.title : "";
            Ge = f.indexOf("Electron") > 0 ? 1 : 0, l = {
                session: ao(),
                ts: Math.round(Date.now()),
                count: 1,
                upgrade: null,
                upload: ""
            }, (s = va("_clsk", !xn.includeSubdomains)) && (c = s.includes("^") ? s.split("^") : s.split("|")).length >= 5 && l.ts - io(c[1]) < 18e5 && (l.session = c[0], l.count = io(c[2]) + 1, l.upgrade = io(c[3]), l.upload = c.length >= 6 ? "https://" + c[5] + "/" + c[4] : "/" === c[4][0] ? c[4] : "https://" + c[4]), a = l, i = ro(), r = xn.projectId || An(location.host), Je = {
                projectId: r,
                userId: i.id,
                sessionId: a.session,
                pageNum: a.count
            }, xn.lean = xn.track && null !== a.upgrade ? 0 === a.upgrade : xn.lean, xn.upload = xn.track && "string" == typeof xn.upload && a.upload && a.upload.length > "https://".length ? a.upload : xn.upload, qr(0, f), qr(3, v), qr(1, Rn(location.href, !!Ge)), qr(2, document.referrer), qr(15, $r()), qr(16, document.documentElement.lang), qr(17, document.dir), qr(26, "" + window.devicePixelRatio), qr(28, "" + i.dob), qr(29, "" + i.version), qr(33, g), qr(34, h), qr(35, p), qr(38, "" + !(!navigator || !navigator.globalPrivacyControl)), Kn(0, a.ts), Kn(1, 0), Kn(35, Ge), (o = null === window || void 0 === window ? void 0 : window.Zone) && "__symbol__" in o && Kn(39, 1), navigator && (qr(9, navigator.language), Kn(33, navigator.hardwareConcurrency), Kn(32, navigator.maxTouchPoints), Kn(34, Math.round(navigator.deviceMemory)), (u = navigator.userAgentData) && u.getHighEntropyValues ? u.getHighEntropyValues(["model", "platformVersion"]).then((function(t) {
                var e;
                qr(22, t.platform), qr(23, t.platformVersion), null === (e = t.brands) || void 0 === e || e.forEach((function(t) {
                    qr(24, t.brand + "~" + t.version)
                })), qr(25, t.model), Kn(27, t.mobile ? 1 : 0)
            })) : qr(22, navigator.platform)), screen && (Kn(14, Math.round(screen.width)), Kn(15, Math.round(screen.height)), Kn(16, Math.round(screen.colorDepth))), null === Ze && (Ze = {
                source: i.consent ? 6 : 0,
                ad_Storage: xn.track ? "granted" : "denied",
                analytics_Storage: xn.track ? "granted" : "denied"
            }), Br(), Fr((d = Gr(Ze)).analytics_Storage ? 1 : 0), Ve = d, no(i)
        },
        stop: function() {
            Je = null, Qe = !1, Ke.forEach((function(t) {
                t.called = !1
            }))
        }
    }, {
        start: function() {
            var t = Je;
            tn = {
                version: e,
                sequence: 0,
                start: 0,
                duration: 0,
                projectId: t.projectId,
                userId: t.userId,
                sessionId: t.sessionId,
                pageNum: t.pageNum,
                upload: 0,
                end: 0,
                applicationPlatform: 0,
                url: ""
            }
        },
        stop: function() {
            tn = null
        }
    }, {
        start: function() {
            Me = !0, we = 0, ke = 0, Oe = !1, _e = 0, Se = [], Ee = [], Ne = {}, xe = null
        },
        stop: function() {
            Zn(Te), kr(!0), we = 0, ke = 0, Oe = !1, _e = 0, Se = [], Ee = [], Ne = {}, xe = null, Me = !1
        }
    }, {
        start: function() {
            v = 6e4, g = 0
        },
        stop: function() {
            Zn(m), g = 0, v = 0
        }
    }, {
        start: function() {
            !xn.lean && xn.upgrade && xn.upgrade("Config"), He = null
        },
        stop: function() {
            He = null
        }
    }, {
        start: function() {
            la()
        },
        stop: function() {
            la()
        }
    }], D = [], A = ["address", "password", "contact"], P = ["radio", "checkbox", "range", "button", "reset", "submit"], R = ["password", "secret", "pass", "social", "ssn", "code", "hidden"], L = ["INPUT", "SELECT", "TEXTAREA"], Y = ["load", "active", "fixed", "visible", "focus", "show", "collaps", "animat"], j = [], X = ["input", "textarea", "radio", "button", "canvas", "select"], W = /VM\d/, H = [], q = [], U = null, z = [], F = [], V = null, B = !1, J = 0, K = new Set, Z = null, Q = !1, $ = Wa(Ha, 500), tt = [], et = null, nt = null, at = null, it = Wa(za, 25), rt = null, ot = null, ut = null, ct = [], ft = !1, ht = [], pt = [], gt = "__clrSId", vt = {}, mt = {}, yt = [], bt = [], wt = [], kt = null, St = !1, Et = "__clrAId", Tt = "__clrOCnt", Nt = 20, Mt = [], _t = new Set, xt = new Set, It = [], Dt = {}, Ct = [], At = null, Pt = null, Rt = null, Lt = {}, Yt = new WeakMap, jt = ["data-google-query-id", "data-load-complete", "data-google-container-id"], Xt = /[^0-9\.]/g, Wt = ["title", "alt", "onload", "onfocus", "onerror", "data-drupal-form-submit-last", "aria-label", "integrity", "crossorigin"], Ht = /[\r\n]+/g, qt = Y, Ut = {}, zt = 1, Ft = null, Vt = [], Bt = [], Jt = {}, Kt = [], Gt = [], Zt = [], Qt = [], $t = [], te = [], ee = null, ne = null, ae = null, ie = null, re = null, oe = [], ue = null, ce = {}, le = [], se = !1, de = null, fe = [], he = [], pe = [], ge = 1, ve = null, me = [], ye = !1, be = null, we = 0, ke = 0, Te = null, _e = 0, Oe = !1, Ie = {}, Ce = {}, Pe = 5e3, Re = {}, Le = [], Ye = null, je = null, Xe = null, We = window.requestIdleCallback || function(t, e) {
        var n = performance.now(),
            a = new MessageChannel,
            i = a.port1,
            r = a.port2;
        i.onmessage = function(a) {
            var i, o = performance.now(),
                u = o - n,
                c = o - a.data;
            c > 30 && u < e.timeout ? requestAnimationFrame((function() {
                r.postMessage(o)
            })) : (i = u > e.timeout, t({
                didTimeout: i,
                timeRemaining: function() {
                    return i ? 30 : Math.max(0, 30 - c)
                }
            }))
        }, requestAnimationFrame((function() {
            r.postMessage(performance.now())
        }))
    }, He = null, Ue = null, ze = null, Fe = !1, Ve = null, Be = !0, Je = null, Ke = [], Ge = 0, Ze = null, Qe = !1, $e = {
        source: 7,
        ad_Storage: "denied",
        analytics_Storage: "denied"
    }, tn = null, nn = new Map, an = null, rn = null, on = null, un = 0, cn = !1, ln = null, sn = 0, dn = 1 / 0, fn = 0, hn = 0, pn = [], gn = new Map, vn = function(t) {
        "interactionCount" in performance ? sn = performance.interactionCount : t.interactionId && (dn = Math.min(dn, t.interactionId), fn = Math.max(fn, t.interactionId), sn = fn ? (fn - dn) / 7 + 1 : 0)
    }, mn = function() {
        return sn || 0
    }, yn = function() {
        return mn() - hn
    }, bn = function() {
        if (!pn.length) return -1;
        var t = Math.min(pn.length - 1, Math.floor(yn() / 50));
        return pn[t].latency
    }, wn = function() {
        hn = mn(), pn.length = 0, gn.clear()
    }, kn = function(t) {
        var e, n, a;
        !t.interactionId || t.duration < 40 || (vn(t), e = pn[pn.length - 1], ((n = gn.get(t.interactionId)) || pn.length < 10 || t.duration > (null == e ? void 0 : e.latency)) && (n ? t.duration > n.latency && (n.latency = t.duration) : (a = {
            id: t.interactionId,
            latency: t.duration
        }, gn.set(a.id, a), pn.push(a)), pn.sort((function(t, e) {
            return e.latency - t.latency
        })), pn.length > 10 && pn.splice(10).forEach((function(t) {
            return gn.delete(t.id)
        }))))
    }, En = ["navigation", "resource", "longtask", "first-input", "layout-shift", "largest-contentful-paint", "event"], Tn = null, Nn = [{
        start: function() {
            ! function() {
                D = [], Kn(26, navigator.webdriver ? 1 : 0);
                try {
                    Kn(31, window.top == window.self || window.top == window ? 1 : 2)
                } catch (t) {
                    Kn(31, 0)
                }
            }(), lo(window, "error", Nr), Ie = {}, Ce = {}
        },
        stop: function() {
            Ce = {}
        }
    }, {
        start: function() {
            Si(), Ei(), sr(), de = null, ue = new WeakMap, ce = {}, le = [], se = !!window.IntersectionObserver, Ui(), zi(document, !0), xn.delayDom ? lo(window, "load", (function() {
                    Ni()
                })) : Ni(),
                function() {
                    var t;
                    try {
                        window.__clr = window.__clr || {}, (null === (t = window.customElements) || void 0 === t ? void 0 : t.define) && !window.__clr.define && (window.__clr.define = window.customElements.define, window.customElements.define = function() {
                            return bo() && mi(arguments[0]), window.__clr.define.apply(this, arguments)
                        })
                    } catch (t) {}
                }(), Yr(), li(),
                function() {
                    var t, e, n;
                    if (window.Animation && window.Animation.prototype && window.KeyframeEffect && window.KeyframeEffect.prototype && window.KeyframeEffect.prototype.getKeyframes && window.KeyframeEffect.prototype.getTiming && (hi(), St || (St = !0, ["play", "pause", "commitStyles", "cancel", "finish"].forEach(gi)), null === kt && (kt = Element.prototype.animate, Element.prototype.animate = function() {
                            var t = kt.apply(this, arguments);
                            return vi(t, "play"), t
                        }), document.getAnimations))
                        for (t = 0, e = document.getAnimations(); t < e.length; t++) "finished" === (n = e[t]).playState ? vi(n, "finish") : "paused" === n.playState || "idle" === n.playState ? vi(n, "pause") : "running" === n.playState && vi(n, "play")
                }()
        },
        stop: function() {
            sr(), ue = null, ce = {}, le = [], de && (de.disconnect(), de = null), se = !1, Ui(),
                function() {
                    var t, e, n;
                    for (t = 0, e = Array.from(xt); t < e.length; t++)(n = e[t]) && n.disconnect();
                    xt = new Set, Lt = {}, It = [], Dt = {}, Ct = [], Rt = 0, At = null, Yt = new WeakMap
                }(), Si(), vt = {}, mt = {}, yt = [], bt = [], di(), hi(), yi(), _t.clear()
        }
    }, {
        start: function() {
            fe = [], pr(), Oa(), Ia(), Xa(), Pa(), Q = !1, lo(window, "resize", $), Ha(), lo(document, "visibilitychange", ei), ei(), lo(window, "focus", (function() {
                    return ii(1)
                })), lo(window, "blur", (function() {
                    return ii(0)
                })),
                function() {
                    if (!ft) try {
                        window[In("addEventListener")]("pageshow", co(ri), {
                            capture: !1,
                            passive: !0
                        }), ft = !0
                    } catch (t) {}
                }(), tt = [], za(), Ga(), ka(), Qa(), lo(window, "pagehide", $a)
        },
        stop: function() {
            fe = [], pr(), Oa(), Ia(), Zn(V), F.length > 0 && ja(F[F.length - 1].event), Zn(U), Pa(), Ua(), ni(), ai(), Zn(at), it.cleanup(), tt = [], et = null, nt = null, Ga(), Zn(ut), ka(), Qa(), ti()
        }
    }, {
        start: function() {
            ko(),
                function() {
                    navigator && navigator.connection && qr(27, navigator.connection.effectiveType), window.PerformanceObserver && PerformanceObserver.supportedEntryTypes ? "complete" !== document.readyState ? lo(window, "load", Gn.bind(this, Eo, 0)) : Eo() : _r(3, 0)
                }()
        },
        stop: function() {
            Sn && Sn.disconnect(), Sn = null, wn(), Tn = null, ko()
        }
    }, {
        start: function() {
            ye = !0, be = new Set, xn.modules && xn.modules.length > 0 && xn.modules.forEach((function(t) {
                br(t)
            }))
        },
        stop: function() {
            me.reverse().forEach((function(t) {
                try {
                    t()
                } catch (t) {}
            })), me = [], ye = !1
        }
    }], Mn = {
        __proto__: null,
        consent: function(t) {
            void 0 === t && (t = !0), Kr(t ? {
                source: 4,
                ad_Storage: "granted",
                analytics_Storage: "granted"
            } : {
                source: 4,
                ad_Storage: "denied",
                analytics_Storage: "denied"
            })
        },
        consentv2: Kr,
        dlog: qr,
        event: Fn,
        hashText: Zi,
        identify: function(t, e, n, a) {
            return void 0 === e && (e = null), void 0 === n && (n = null), void 0 === a && (a = null), $n(this, void 0, void 0, (function() {
                var i, r;
                return ta(this, (function(o) {
                    switch (o.label) {
                        case 0:
                            return r = {}, [4, ra(t)];
                        case 1:
                            return r.userId = o.sent(), r.userHint = a || ((u = t) && u.length >= 5 ? u.substring(0, 2) + jn(u.substring(2), "*", "*") : jn(u, "*", "*")), aa("userId", [(i = r).userId]), aa("userHint", [i.userHint]), aa("userType", [oa(t)]), e && (aa("sessionId", [e]), i.sessionId = e), n && (aa("pageId", [n]), i.pageId = n), [2, i]
                    }
                    var u
                }))
            }))
        },
        maxMetric: Kn,
        measure: co,
        metadata: function(t, e, n, a) {
            var i, r;
            void 0 === e && (e = !0), void 0 === n && (n = !1), void 0 === a && (a = !1), i = xn.lean ? 0 : 1, r = !1, Je && (i || !1 === e) && (t(Je, !xn.lean, a ? Ze : void 0), r = !0), !n && r || Ke.push({
                callback: t,
                wait: e,
                recall: n,
                called: r,
                consentInfo: a
            })
        },
        pause: function() {
            bo() && (Fn("clarity", "pause"), null === je && (je = new Promise((function(t) {
                Xe = t
            }))))
        },
        queue: wr,
        register: function(t) {
            ye && "function" == typeof t && me.push(t)
        },
        resume: function() {
            bo() && (je && (Xe(), je = null, null === Ye && Ir()), Fn("clarity", "resume"))
        },
        schedule: xr,
        set: na,
        signal: function(t) {
            x = t
        },
        start: Mo,
        stop: _o,
        time: Cn,
        upgrade: Xr,
        version: e
    }, _n = window, On = "clarity", Oo()
}();