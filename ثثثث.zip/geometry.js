google.maps.__gjsload__('geometry', function(_) {
    var ksa = function(a, b) {
            return Math.abs(_.Dl(b - a, -180, 180))
        },
        lsa = function(a, b, c, d, e) {
            if (!d) {
                c = ksa(a.lng(), c) / ksa(a.lng(), b.lng());
                if (!e) return e = Math.sin(_.Qk(a.lat())), e = Math.log((1 + e) / (1 - e)) / 2, b = Math.sin(_.Qk(b.lat())), _.Rk(2 * Math.atan(Math.exp(e + c * (Math.log((1 + b) / (1 - b)) / 2 - e))) - Math.PI / 2);
                a = e.fromLatLngToPoint(a);
                b = e.fromLatLngToPoint(b);
                return e.fromPointToLatLng(new _.En(a.x + c * (b.x - a.x), a.y + c * (b.y - a.y))).lat()
            }
            e = _.Qk(a.lat());
            a = _.Qk(a.lng());
            d = _.Qk(b.lat());
            b = _.Qk(b.lng());
            c = _.Qk(c);
            return _.Dl(_.Rk(Math.atan2(Math.sin(e) *
                Math.cos(d) * Math.sin(c - b) - Math.sin(d) * Math.cos(e) * Math.sin(c - a), Math.cos(e) * Math.cos(d) * Math.sin(a - b))), -90, 90)
        },
        msa = function(a, b) {
            a = new _.sm(a, !1);
            b = new _.sm(b, !1);
            return a.equals(b)
        },
        nsa = function(a, b, c) {
            a = _.wm(a);
            c = c || 1E-9;
            var d = _.Dl(a.lng(), -180, 180),
                e = b instanceof _.Xs,
                f = !!b.get("geodesic"),
                g = b.get("latLngs");
            b = b.get("map");
            b = !f && b ? b.getProjection() : null;
            for (let q = 0, u = g.getLength(); q < u; ++q) {
                let x = g.getAt(q),
                    z = x.getLength(),
                    B = e ? z : z - 1;
                for (let L = 0; L < B; ++L) {
                    var h = x.getAt(L);
                    let O = x.getAt((L + 1) % z);
                    if (msa(h, a) || msa(O, a)) return !0;
                    var k = _.Dl(h.lng(), -180, 180),
                        m = _.Dl(O.lng(), -180, 180);
                    let U = Math.max(k, m),
                        A = Math.min(k, m);
                    if (k = Math.abs(_.Dl(k - m, -180, 180)) <= 1E-9 && (Math.abs(_.Dl(k - d, -180, 180)) <= c || Math.abs(_.Dl(m - d, -180, 180)) <= c)) {
                        k = a.lat();
                        m = Math.min(h.lat(), O.lat()) - c;
                        var p = Math.max(h.lat(), O.lat()) + c;
                        k = k >= m && k <= p
                    }
                    if (k) return !0;
                    if (U - A > 180 ? d + c >= U || d - c <= A : d + c >= A && d - c <= U)
                        if (h = lsa(h, O, d, f, b), Math.abs(h - a.lat()) < c) return !0
                }
            }
            return !1
        },
        osa = function(a, b) {
            var c = _.tm(a);
            a = _.um(a);
            var d = _.tm(b);
            b = _.um(b);
            return 2 *
                Math.asin(Math.sqrt(Math.pow(Math.sin((c - d) / 2), 2) + Math.cos(c) * Math.cos(d) * Math.pow(Math.sin((a - b) / 2), 2)))
        },
        psa = function(a, b, c) {
            a = _.wm(a);
            b = _.wm(b);
            c = c || 6378137;
            return osa(a, b) * c
        },
        ssa = function(a, b) {
            b = b || 6378137;
            a instanceof _.go && (a = a.getArray());
            a = (0, _.Gr)(a);
            if (a.length === 0) return 0;
            var c = Array(4),
                d = Array(3),
                e = [1, 0, 0, 0],
                f = Array(3);
            qsa(a[a.length - 1], f);
            for (let x = 0; x < a.length; ++x) qsa(a[x], d), tB(f, d, c), rsa(c, e, e), [f[0], f[1], f[2]] = d;
            var [g, h, k] = f, [m, p, q, u] = e;
            return 2 * Math.atan2(g * p + h * q + k * u, m) * (b * b)
        },
        tsa = function(a, b) {
            if (isFinite(a)) {
                var c = a % 360;
                a = Math.round(c / 90);
                c -= a * 90;
                if (c === 30 || c === -30) {
                    c = Math.sign(c) * .5;
                    var d = Math.sqrt(.75)
                } else c === 45 || c === -45 ? (c = Math.sign(c) * Math.SQRT1_2, d = Math.SQRT1_2) : (d = c / 180 * Math.PI, c = Math.sin(d), d = Math.cos(d));
                switch (a & 3) {
                    case 0:
                        b[0] = c;
                        b[1] = d;
                        break;
                    case 1:
                        b[0] = d;
                        b[1] = -c;
                        break;
                    case 2:
                        b[0] = -c;
                        b[1] = -d;
                        break;
                    default:
                        b[0] = -d, b[1] = c
                }
            } else b[0] = NaN, b[1] = NaN
        },
        qsa = function(a, b) {
            var c = Array(2);
            tsa(a.lat(), c);
            var [d, e] = c;
            tsa(a.lng(), c);
            var [f, g] = c;
            b[0] = e * g;
            b[1] = e * f;
            b[2] = d
        },
        rsa = function(a, b, c) {
            var d = a[0] * b[1] + a[1] * b[0] + a[2] * b[3] - a[3] * b[2],
                e = a[0] * b[2] - a[1] * b[3] + a[2] * b[0] + a[3] * b[1],
                f = a[0] * b[3] + a[1] * b[2] - a[2] * b[1] + a[3] * b[0];
            c[0] = a[0] * b[0] - a[1] * b[1] - a[2] * b[2] - a[3] * b[3];
            c[1] = d;
            c[2] = e;
            c[3] = f
        },
        tB = function(a, b, c) {
            var d = a[0] - b[0],
                e = a[1] - b[1],
                f = a[2] - b[2],
                g = a[0] + b[0],
                h = a[1] + b[1],
                k = a[2] + b[2],
                m = g * g + h * h + k * k,
                p = e * k - f * h;
            f = f * g - d * k;
            d = d * h - e * g;
            e = m * m + p * p + f * f + d * d;
            if (e !== 0) b = Math.sqrt(e), c[0] = m / b, c[1] = p / b, c[2] = f / b, c[3] = d / b;
            else {
                a: for (m = [a[0] - b[0], a[1] - b[1], a[2] - b[2]], p = 0; p < 3; ++p)
                    if (m[p] !==
                        0) {
                        if (m[p] < 0) {
                            m = [-m[0], -m[1], -m[2]];
                            break a
                        }
                        break
                    }p = 0;
                for (f = 1; f < m.length; ++f) Math.abs(m[f]) < Math.abs(m[p]) && (p = f);f = [0, 0, 0];f[p] = 1;m = [m[1] * f[2] - m[2] * f[1], m[2] * f[0] - m[0] * f[2], m[0] * f[1] - m[1] * f[0]];p = Math.hypot(...m);m = [m[0] / p, m[1] / p, m[2] / p];p = Array(4);tB(a, m, p);a = Array(4);tB(m, b, a);rsa(a, p, c)
            }
        },
        uB = class {};
    uB.isLocationOnEdge = nsa;
    uB.containsLocation = function(a, b) {
        a = _.wm(a);
        var c = _.Dl(a.lng(), -180, 180),
            d = !!b.get("geodesic"),
            e = b.get("latLngs"),
            f = b.get("map");
        f = !d && f ? f.getProjection() : null;
        var g = !1;
        for (let k = 0, m = e.getLength(); k < m; ++k) {
            let p = e.getAt(k);
            for (let q = 0, u = p.getLength(); q < u; ++q) {
                let x = p.getAt(q),
                    z = p.getAt((q + 1) % u);
                var h = _.Dl(x.lng(), -180, 180);
                let B = _.Dl(z.lng(), -180, 180),
                    L = Math.max(h, B);
                h = Math.min(h, B);
                (L - h > 180 ? c >= L || c < h : c < L && c >= h) && lsa(x, z, c, d, f) < a.lat() && (g = !g)
            }
        }
        return g || nsa(a, b)
    };
    var vB = class {};
    vB.computeSignedArea = ssa;
    vB.computeArea = function(a, b) {
        if (!(a instanceof _.go || Array.isArray(a) || a instanceof _.tn || a instanceof _.no)) try {
            a = _.vn(a)
        } catch (c) {
            try {
                a = new _.no((0, _.Oja)(a))
            } catch (d) {
                throw _.Wl("Invalid path passed to computeArea(): " + JSON.stringify(a));
            }
        }
        b = b || 6378137;
        if (a instanceof _.no) {
            if (a.getRadius() === void 0) throw _.Wl("Invalid path passed to computeArea(): Circle is missing radius.");
            if (a.getRadius() < 0) throw _.Wl("Invalid path passed to computeArea(): Circle must have non-negative radius.");
            if (b < 0) throw _.Wl("Invalid radiusOfSphere passed to computeArea(): radiusOfSphere must be non-negative.");
            if (a.getRadius() > Math.PI * b) throw _.Wl("Invalid path passed to computeArea(): Circle must not cover more than 100% of the sphere.");
            return 2 * Math.PI * b ** 2 * (1 - Math.cos(a.getRadius() / b))
        }
        if (a instanceof _.tn) {
            if (b < 0) throw _.Wl("Invalid radiusOfSphere passed to computeArea(): radiusOfSphere must be non-negative.");
            if (a.lat.lo > a.lat.hi) throw _.Wl("Invalid path passed to computeArea(): the southern LatLng of a LatLngBounds cannot be more north than the northern LatLng.");
            let c = 2 * Math.PI * b ** 2 * (1 - Math.cos((a.lat.lo -
                90) * Math.PI / 180));
            c -= 2 * Math.PI * b ** 2 * (1 - Math.cos((a.lat.hi - 90) * Math.PI / 180));
            return c * Math.abs(a.lng.hi - a.lng.lo) / 360
        }
        return Math.abs(ssa(a, b))
    };
    vB.computeLength = function(a, b) {
        b = b || 6378137;
        var c = 0;
        a instanceof _.go && (a = a.getArray());
        for (let d = 0, e = a.length - 1; d < e; ++d) c += psa(a[d], a[d + 1], b);
        return c
    };
    vB.computeDistanceBetween = psa;
    vB.traversePath = function() {
        throw Error("traversePath() is not available in this version of the Maps JavaScript API.");
    };
    vB.interpolate = function(a, b, c) {
        a = _.wm(a);
        b = _.wm(b);
        var d = _.tm(a),
            e = _.um(a),
            f = _.tm(b),
            g = _.um(b),
            h = Math.cos(d),
            k = Math.cos(f);
        b = osa(a, b);
        var m = Math.sin(b);
        if (m < 1E-6) return new _.sm(a.lat(), a.lng());
        a = Math.sin((1 - c) * b) / m;
        c = Math.sin(c * b) / m;
        b = a * h * Math.cos(e) + c * k * Math.cos(g);
        e = a * h * Math.sin(e) + c * k * Math.sin(g);
        return new _.sm(_.Rk(Math.atan2(a * Math.sin(d) + c * Math.sin(f), Math.sqrt(b * b + e * e))), _.Rk(Math.atan2(e, b)))
    };
    vB.computeOffsetOrigin = function(a, b, c, d) {
        a = _.wm(a);
        c = _.Qk(c);
        b /= d || 6378137;
        d = Math.cos(b);
        var e = Math.sin(b) * Math.cos(c);
        b = Math.sin(b) * Math.sin(c);
        c = Math.sin(_.tm(a));
        var f = e * e * d * d + d * d * d * d - d * d * c * c;
        if (f < 0) return null;
        var g = e * c + Math.sqrt(f);
        g /= d * d + e * e;
        var h = (c - e * g) / d;
        g = Math.atan2(h, g);
        if (g < -Math.PI / 2 || g > Math.PI / 2) g = e * c - Math.sqrt(f), g = Math.atan2(h, g / (d * d + e * e));
        if (g < -Math.PI / 2 || g > Math.PI / 2) return null;
        a = _.um(a) - Math.atan2(b, d * Math.cos(g) - e * Math.sin(g));
        return new _.sm(_.Rk(g), _.Rk(a))
    };
    vB.computeOffset = function(a, b, c, d) {
        a = _.wm(a);
        b /= d || 6378137;
        c = _.Qk(c);
        var e = _.tm(a);
        a = _.um(a);
        d = Math.cos(b);
        b = Math.sin(b);
        var f = Math.sin(e);
        e = Math.cos(e);
        var g = d * f + b * e * Math.cos(c);
        return new _.sm(_.Rk(Math.asin(g)), _.Rk(a + Math.atan2(b * e * Math.sin(c), d - f * g)))
    };
    vB.computeHeading = function(a, b) {
        a = _.wm(a);
        b = _.wm(b);
        var c = _.tm(a),
            d = _.um(a);
        a = _.tm(b);
        b = _.um(b) - d;
        return _.Dl(_.Rk(Math.atan2(Math.sin(b) * Math.cos(a), Math.cos(c) * Math.sin(a) - Math.sin(c) * Math.cos(a) * Math.cos(b))), -180, 180)
    };
    var usa = {
        encoding: _.tt,
        spherical: vB,
        poly: uB
    };
    _.Xa.google.maps.geometry = usa;
    _.el("geometry", usa);
});